'use client';

import { useState, useEffect } from 'react';
import { createClient } from '@/lib/supabase/client';
import { useLojaAdmin } from '@/hooks/useLojaAdmin';
import Button from '@/components/ui/Button';
import toast from 'react-hot-toast';
import { AlertTriangle, Package, TrendingDown } from 'lucide-react';

interface VarianteEstoque {
  id: string;
  produto_id: string;
  produto_nome: string;
  produto_slug: string;
  tamanho: string;
  cor: string | null;
  cor_hex: string | null;
  estoque: number;
  sku: string | null;
}

export default function AdminEstoquePage() {
  const [variantes, setVariantes] = useState<VarianteEstoque[]>([]);
  const [loading, setLoading] = useState(true);
  const [salvando, setSalvando] = useState<string | null>(null);
  const [filtro, setFiltro] = useState<'todos' | 'critico' | 'zerado'>('todos');
  const [busca, setBusca] = useState('');

  const { lojaId } = useLojaAdmin();

  useEffect(() => {
    carregarEstoque();
  }, []);

  async function carregarEstoque() {
    setLoading(true);
    try {
      // API server-side com service role (bypassa RLS) — mostra todos os produtos
      const res = await fetch('/api/admin/listar-estoque', { cache: 'no-store' });
      if (!res.ok) throw new Error('Falha ao carregar estoque');
      const data = await res.json();

      setVariantes((Array.isArray(data) ? data : []).map((v: {
        id: string; produto_id: string; tamanho: string;
        cor: string | null; cor_hex: string | null; estoque: number; sku: string | null;
        produtos: { nome: string; slug: string } | null;
      }) => ({
        id: v.id, produto_id: v.produto_id,
        produto_nome: v.produtos?.nome ?? '—',
        produto_slug: v.produtos?.slug ?? '',
        tamanho: v.tamanho, cor: v.cor, cor_hex: v.cor_hex,
        estoque: v.estoque, sku: v.sku,
      })));
    } catch {
      toast.error('Erro ao carregar estoque');
    } finally {
      setLoading(false);
    }
  }

  async function salvarEstoque(varianteId: string, novoEstoque: number) {
    if (novoEstoque < 0) { toast.error('Estoque mínimo é 0'); return; }
    setSalvando(varianteId);
    try {
      // Usa API admin (service role) para bypasser o RLS do Supabase
      const res = await fetch('/api/admin/estoque', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ variante_id: varianteId, estoque: novoEstoque }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erro ao salvar');
      setVariantes(prev => prev.map(v => v.id === varianteId ? { ...v, estoque: novoEstoque } : v));
      toast.success('Estoque atualizado');
    } catch (e: any) {
      toast.error(e.message || 'Erro ao salvar estoque');
    } finally {
      setSalvando(null);
    }
  }

  const filtradas = variantes.filter(v => {
    const matchBusca = v.produto_nome.toLowerCase().includes(busca.toLowerCase()) ||
      v.tamanho.toLowerCase().includes(busca.toLowerCase()) ||
      (v.cor?.toLowerCase().includes(busca.toLowerCase()) ?? false);
    if (filtro === 'critico') return v.estoque > 0 && v.estoque <= 2 && matchBusca;
    if (filtro === 'zerado') return v.estoque === 0 && matchBusca;
    return matchBusca;
  });

  const stats = {
    total: variantes.length,
    criticos: variantes.filter(v => v.estoque > 0 && v.estoque <= 2).length,
    zerados: variantes.filter(v => v.estoque === 0).length,
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-serif text-charcoal">Gestão de Estoque</h1>
          <p className="text-charcoal-muted text-sm mt-1">Controle estoque por produto, tamanho e cor. Mínimo: 1 peça.</p>
        </div>
        <Button variant="outline" size="sm" onClick={carregarEstoque} loading={loading}>
          Atualizar
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-white p-4 rounded-sm shadow-sm">
          <div className="flex items-center gap-2 mb-1">
            <Package size={16} className="text-gold" />
            <p className="text-xs text-charcoal-muted uppercase tracking-wider">Total Variantes</p>
          </div>
          <p className="text-2xl font-bold text-charcoal">{stats.total}</p>
        </div>
        <div className="bg-white p-4 rounded-sm shadow-sm border-l-4 border-amber-400">
          <div className="flex items-center gap-2 mb-1">
            <AlertTriangle size={16} className="text-amber-500" />
            <p className="text-xs text-charcoal-muted uppercase tracking-wider">Estoque Crítico (≤2)</p>
          </div>
          <p className="text-2xl font-bold text-amber-600">{stats.criticos}</p>
        </div>
        <div className="bg-white p-4 rounded-sm shadow-sm border-l-4 border-red-400">
          <div className="flex items-center gap-2 mb-1">
            <TrendingDown size={16} className="text-red-500" />
            <p className="text-xs text-charcoal-muted uppercase tracking-wider">Zerados</p>
          </div>
          <p className="text-2xl font-bold text-red-600">{stats.zerados}</p>
        </div>
      </div>

      {/* Filtros */}
      <div className="flex flex-wrap gap-2 mb-4">
        <input value={busca} onChange={e => setBusca(e.target.value)}
          placeholder="Buscar produto, tamanho ou cor..."
          className="input-field max-w-xs text-sm" />
        {(['todos', 'critico', 'zerado'] as const).map(f => (
          <button key={f} onClick={() => setFiltro(f)}
            className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider border transition-colors ${filtro === f ? 'bg-charcoal text-white border-charcoal' : 'border-gray-200 text-charcoal hover:border-charcoal'}`}>
            {f === 'todos' ? 'Todos' : f === 'critico' ? '⚠️ Crítico' : '🚨 Zerado'}
          </button>
        ))}
      </div>

      {/* Tabela */}
      <div className="bg-white rounded-sm shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-cream-darker bg-cream">
              {['Produto', 'Tamanho', 'Cor', 'SKU', 'Estoque', 'Ações'].map(h => (
                <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-charcoal-muted uppercase tracking-wider">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={6} className="px-5 py-12 text-center text-charcoal-muted">Carregando...</td></tr>
            ) : filtradas.length === 0 ? (
              <tr><td colSpan={6} className="px-5 py-12 text-center text-charcoal-muted">Nenhum resultado</td></tr>
            ) : filtradas.map(v => (
              <tr key={v.id} className={`border-b border-cream-darker ${v.estoque === 0 ? 'bg-red-50' : v.estoque <= 2 ? 'bg-amber-50' : ''}`}>
                <td className="px-5 py-3">
                  <a href={`/produtos/${v.produto_slug}`} target="_blank" rel="noopener"
                    className="font-semibold text-charcoal hover:text-gold transition-colors text-xs">
                    {v.produto_nome}
                  </a>
                </td>
                <td className="px-5 py-3">
                  <span className="inline-flex items-center justify-center w-10 h-10 border border-gray-200 font-semibold text-sm">
                    {v.tamanho}
                  </span>
                </td>
                <td className="px-5 py-3">
                  <div className="flex items-center gap-2">
                    {v.cor_hex && (
                      <span className="w-5 h-5 rounded-full border border-gray-200 shrink-0"
                        style={{ backgroundColor: v.cor_hex }} />
                    )}
                    <span className="text-charcoal-muted text-xs">{v.cor ?? '—'}</span>
                  </div>
                </td>
                <td className="px-5 py-3 text-charcoal-muted text-xs font-mono">{v.sku ?? '—'}</td>
                <td className="px-5 py-3">
                  <div className="flex items-center gap-2">
                    <button onClick={() => salvarEstoque(v.id, Math.max(0, v.estoque - 1))}
                      disabled={v.estoque <= 0 || salvando === v.id}
                      className="w-7 h-7 border border-gray-200 flex items-center justify-center hover:bg-gray-50 disabled:opacity-40 text-sm">−</button>
                    <span className={`w-10 text-center font-bold ${v.estoque === 0 ? 'text-red-600' : v.estoque <= 2 ? 'text-amber-600' : 'text-green-600'}`}>
                      {v.estoque}
                    </span>
                    <button onClick={() => salvarEstoque(v.id, v.estoque + 1)}
                      disabled={salvando === v.id}
                      className="w-7 h-7 border border-gray-200 flex items-center justify-center hover:bg-gray-50 text-sm">+</button>
                  </div>
                </td>
                <td className="px-5 py-3">
                  <div className="flex gap-2">
                    {[1, 5, 10].map(n => (
                      <button key={n} onClick={() => salvarEstoque(v.id, v.estoque + n)}
                        disabled={salvando === v.id}
                        className="text-[10px] text-gold hover:underline disabled:opacity-40">
                        +{n}
                      </button>
                    ))}
                    <span className="text-gray-300">|</span>
                    <button onClick={() => { const novo = parseInt(prompt(`Estoque para ${v.produto_nome} (${v.tamanho}/${v.cor}):`) ?? String(v.estoque)); if (!isNaN(novo)) salvarEstoque(v.id, novo); }}
                      className="text-[10px] text-charcoal-muted hover:text-charcoal">
                      Definir
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
