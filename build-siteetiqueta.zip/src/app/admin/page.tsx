import StatCard from '@/components/admin/StatCard';
import { formatPrice } from '@/lib/utils';
import { ShoppingCart, DollarSign, Users, Package, Clock, ArrowUpRight } from 'lucide-react';
import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = { title: 'Dashboard — Admin' };
export const dynamic = 'force-dynamic';

type PedidoRow = {
  id: string; total: number; status: string;
  numero: number; created_at: string;
  clientes: { nome: string } | null;
};

const statusStyles: Record<string, { bg: string; text: string; dot: string }> = {
  pago:        { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500' },
  pendente:    { bg: 'bg-amber-50',   text: 'text-amber-700',   dot: 'bg-amber-400' },
  processando: { bg: 'bg-blue-50',    text: 'text-blue-700',    dot: 'bg-blue-500' },
  enviado:     { bg: 'bg-purple-50',  text: 'text-purple-700',  dot: 'bg-purple-500' },
  entregue:    { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500' },
  cancelado:   { bg: 'bg-red-50',     text: 'text-red-600',     dot: 'bg-red-400' },
  reembolsado: { bg: 'bg-gray-100',   text: 'text-gray-600',    dot: 'bg-gray-400' },
};

async function getLojaDoAdmin(): Promise<{ lojaId: string; nomeLoja: string }> {
  try {
    const { createClient: server } = await import('@/lib/supabase/server');
    const { createClient: admin } = await import('@/lib/supabase/admin');
    const s = server();
    const { data: { user } } = await s.auth.getUser();
    if (!user) return { lojaId: '00000000-0000-0000-0000-000000000001', nomeLoja: 'Sua Loja' };
    const a = admin();
    const { data: adminRow } = await a.from('admins').select('loja_id').eq('id', user.id).maybeSingle();
    const lojaId = adminRow?.loja_id || '00000000-0000-0000-0000-000000000001';
    const { data: loja } = await a.from('lojas').select('nome').eq('id', lojaId).maybeSingle();
    return { lojaId, nomeLoja: loja?.nome || 'Sua Loja' };
  } catch {
    return { lojaId: '00000000-0000-0000-0000-000000000001', nomeLoja: 'Sua Loja' };
  }
}

async function getStats(lojaId: string) {
  try {
    const { createClient } = await import('@/lib/supabase/admin');
    const supabase = createClient();
    const [
      { count: totalPedidos },
      { data: pedidos },
      { count: totalClientes },
      { count: totalProdutos },
    ] = await Promise.all([
      supabase.from('pedidos').select('*', { count: 'exact', head: true }).eq('loja_id', lojaId),
      supabase.from('pedidos').select('id, total, status, numero, created_at, clientes(nome)').eq('loja_id', lojaId).order('created_at', { ascending: false }).limit(8),
      supabase.from('clientes').select('*', { count: 'exact', head: true }).eq('loja_id', lojaId),
      supabase.from('produtos').select('*', { count: 'exact', head: true }).eq('loja_id', lojaId).eq('ativo', true),
    ]);
    const rows = (pedidos ?? []) as PedidoRow[];
    const faturamento = rows.filter(p => ['pago','enviado','entregue'].includes(p.status)).reduce((s, p) => s + Number(p.total), 0);
    return { totalPedidos: totalPedidos ?? 0, faturamento, totalClientes: totalClientes ?? 0, totalProdutos: totalProdutos ?? 0, recentPedidos: rows };
  } catch {
    return { totalPedidos: 0, faturamento: 0, totalClientes: 0, totalProdutos: 0, recentPedidos: [] };
  }
}

export default async function AdminDashboard() {
  const { lojaId, nomeLoja } = await getLojaDoAdmin();
  const { totalPedidos, faturamento, totalClientes, totalProdutos, recentPedidos } = await getStats(lojaId);

  return (
    <div>
      {/* Header */}
      <div className="mb-5 sm:mb-8">
        <div className="flex items-center gap-2 mb-1.5">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[10px] sm:text-[11px] text-emerald-600 font-semibold uppercase tracking-wider">Sistema online</span>
        </div>
        <h1 className="text-xl sm:text-2xl font-serif text-charcoal tracking-tight">Dashboard</h1>
        <p className="text-gray-400 text-xs sm:text-sm mt-1">Visão geral da {nomeLoja}</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-5 sm:mb-8">
        <StatCard title="Faturamento Total" value={formatPrice(faturamento)} icon={DollarSign} color="gold" />
        <StatCard title="Total de Pedidos" value={String(totalPedidos)} icon={ShoppingCart} color="blue" />
        <StatCard title="Clientes" value={String(totalClientes)} icon={Users} color="green" />
        <StatCard title="Produtos Ativos" value={String(totalProdutos)} icon={Package} color="rose" />
      </div>

      {/* Pedidos Recentes */}
      <div className="bg-white border border-gray-100 rounded-2xl overflow-hidden shadow-sm">
        <div className="px-4 sm:px-6 py-4 sm:py-5 border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-blue-50 flex items-center justify-center">
              <Clock size={14} className="text-blue-500" />
            </div>
            <div>
              <h2 className="font-semibold text-charcoal text-sm">Pedidos Recentes</h2>
              <p className="text-[10px] sm:text-[11px] text-gray-400 hidden sm:block">Últimas transações</p>
            </div>
          </div>
          <Link href="/admin/pedidos" className="flex items-center gap-1 text-xs text-gold font-semibold hover:text-gold-600 transition-colors">
            Ver todos <ArrowUpRight size={12} />
          </Link>
        </div>

        {/* Mobile: cards empilhados */}
        <div className="sm:hidden divide-y divide-gray-50">
          {recentPedidos.length === 0 ? (
            <div className="py-12 text-center">
              <ShoppingCart size={28} className="text-gray-200 mx-auto mb-2" />
              <p className="text-gray-400 text-sm">Nenhum pedido ainda</p>
            </div>
          ) : recentPedidos.map((p) => {
            const s = statusStyles[p.status] ?? statusStyles.pendente;
            return (
              <div key={p.id} className="flex items-center justify-between px-4 py-3 hover:bg-gray-50 transition-colors">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono text-charcoal text-xs bg-gray-100 px-2 py-0.5 rounded">#{p.numero}</span>
                    <span className={`inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-md ${s.bg} ${s.text}`}>
                      <span className={`w-1 h-1 rounded-full ${s.dot}`} />
                      {p.status}
                    </span>
                  </div>
                  <p className="text-xs text-charcoal-muted">{p.clientes?.nome ?? '—'}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-charcoal text-sm">{formatPrice(Number(p.total))}</p>
                  <p className="text-[10px] text-gray-400">{new Date(p.created_at).toLocaleDateString('pt-BR')}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Desktop: tabela */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-50 bg-gray-50/60">
                {['Pedido','Cliente','Status','Total','Data'].map(h => (
                  <th key={h} className="text-left px-4 sm:px-6 py-3 text-[11px] font-semibold text-gray-400 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {recentPedidos.length === 0 ? (
                <tr><td colSpan={5} className="px-6 py-12 text-center">
                  <ShoppingCart size={28} className="text-gray-200 mx-auto mb-2" />
                  <p className="text-gray-400 text-sm">Nenhum pedido ainda</p>
                </td></tr>
              ) : recentPedidos.map(p => {
                const s = statusStyles[p.status] ?? statusStyles.pendente;
                return (
                  <tr key={p.id} className="border-b border-gray-50 hover:bg-gray-50/60 transition-colors">
                    <td className="px-4 sm:px-6 py-3 sm:py-4">
                      <span className="font-mono text-charcoal text-xs bg-gray-100 px-2 py-1 rounded-lg">#{p.numero}</span>
                    </td>
                    <td className="px-4 sm:px-6 py-3 sm:py-4 text-charcoal-muted text-[13px]">{p.clientes?.nome ?? '—'}</td>
                    <td className="px-4 sm:px-6 py-3 sm:py-4">
                      <span className={`inline-flex items-center gap-1.5 text-[11px] font-semibold px-2.5 py-1 rounded-lg ${s.bg} ${s.text}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`} />{p.status}
                      </span>
                    </td>
                    <td className="px-4 sm:px-6 py-3 sm:py-4 font-bold text-charcoal text-[13px]">{formatPrice(Number(p.total))}</td>
                    <td className="px-4 sm:px-6 py-3 sm:py-4 text-gray-400 text-xs">{new Date(p.created_at).toLocaleDateString('pt-BR')}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
