import { NextRequest, NextResponse } from 'next/server';
import { createClient as createServer } from '@/lib/supabase/server';
import { createClient as createAdmin } from '@/lib/supabase/admin';
import { gerarEtiquetaCompleta, type DadosEtiqueta } from '@/lib/melhorenvio';

const LOJA_DEFAULT = '00000000-0000-0000-0000-000000000001';

/**
 * Gera etiqueta de envio via Melhor Envio pra um pedido.
 * Faz o fluxo completo: cart → checkout → generate → print → tracking.
 *
 * Body: { servico_id: number, peso_kg?: number }
 * Resposta: { ok, trackingCode, printUrl, melhorenvioOrderId }
 */
export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const server = createServer();
    const { data: { user } } = await server.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });

    const admin = createAdmin();
    const { data: adminRow } = await admin.from('admins').select('loja_id').eq('id', user.id).maybeSingle();
    const { data: superRow } = await admin.from('super_admins').select('id').eq('id', user.id).maybeSingle();
    if (!adminRow && !superRow) return NextResponse.json({ error: 'Sem permissão' }, { status: 403 });

    const lojaId = adminRow?.loja_id || LOJA_DEFAULT;
    const pedidoId = params.id;
    const body = await req.json().catch(() => ({}));
    const servicoIdRaw = body?.servico_id;
    const servicoId = typeof servicoIdRaw === 'number' ? servicoIdRaw : parseInt(servicoIdRaw ?? '1');
    const pesoTotal = typeof body?.peso_kg === 'number' ? body.peso_kg : 0.5;

    // 1. Busca configs da loja (CEP origem + token Melhor Envio + dados de identidade)
    const { data: configsData } = await admin
      .from('configuracoes')
      .select('chave, valor')
      .eq('loja_id', lojaId)
      .in('chave', [
        'loja_cep_origem', 'melhorenvio_token', 'loja_nome', 'loja_email',
        'loja_whatsapp', 'loja_cnpj', 'rodape_rua',
      ]);
    const cfg: Record<string, string> = {};
    (configsData ?? []).forEach((c: { chave: string; valor: string | null }) => {
      cfg[c.chave] = c.valor ?? '';
    });

    const token = cfg.melhorenvio_token;
    if (!token) {
      return NextResponse.json({ error: 'Token Melhor Envio não configurado' }, { status: 400 });
    }
    const cepOrigem = cfg.loja_cep_origem || '55002000';
    const nomeLoja = cfg.loja_nome || 'Loja';
    const emailLoja = cfg.loja_email || 'contato@loja.com.br';
    const whatsappLoja = cfg.loja_whatsapp || '81994228240';
    const cnpjLoja = cfg.loja_cnpj?.replace(/\D/g, '') || '00000000000000';

    // 2. Busca pedido + itens + cliente + endereço
    const { data: pedido } = await admin
      .from('pedidos')
      .select('*, clientes(nome, sobrenome, cpf, telefone, whatsapp)')
      .eq('id', pedidoId)
      .eq('loja_id', lojaId)
      .maybeSingle();

    if (!pedido) return NextResponse.json({ error: 'Pedido não encontrado' }, { status: 404 });

    // Se já tem código de rastreio gerado, retorna ele
    const pedidoAny = pedido as any;
    if (pedidoAny.codigo_rastreio && pedidoAny.melhorenvio_order_id) {
      return NextResponse.json({
        ok: true,
        trackingCode: pedidoAny.codigo_rastreio,
        printUrl: pedidoAny.melhorenvio_print_url || null,
        melhorenvioOrderId: pedidoAny.melhorenvio_order_id,
        ja_gerada: true,
      });
    }

    // Endereço de entrega
    let endereco: any = null;
    if (pedidoAny.endereco_entrega_id) {
      const { data: end } = await admin
        .from('enderecos')
        .select('*')
        .eq('id', pedidoAny.endereco_entrega_id)
        .maybeSingle();
      endereco = end;
    }
    if (!endereco) {
      return NextResponse.json({ error: 'Pedido sem endereço de entrega' }, { status: 400 });
    }

    // Itens
    const { data: itens } = await admin
      .from('pedido_itens')
      .select('nome_produto, quantidade, preco_unitario')
      .eq('pedido_id', pedidoId);

    if (!itens || itens.length === 0) {
      return NextResponse.json({ error: 'Pedido sem itens' }, { status: 400 });
    }

    const cliente = pedidoAny.clientes;
    const dados: DadosEtiqueta = {
      servico_id: servicoId,
      from: {
        name: nomeLoja, phone: whatsappLoja, email: emailLoja,
        document: cnpjLoja, address: cfg.rodape_rua || 'Caruaru/PE', number: '0',
        district: 'Centro', city: 'Caruaru', country_id: 'BR',
        postal_code: cepOrigem.replace(/\D/g, ''), state_abbr: 'PE',
      },
      to: {
        name: `${cliente?.nome ?? ''} ${cliente?.sobrenome ?? ''}`.trim() || 'Cliente',
        phone: cliente?.telefone || cliente?.whatsapp || whatsappLoja,
        email: emailLoja,
        document: cliente?.cpf?.replace(/\D/g, '') || cnpjLoja,
        address: endereco.rua, number: endereco.numero,
        complement: endereco.complemento || undefined,
        district: endereco.bairro, city: endereco.cidade,
        country_id: 'BR',
        postal_code: (endereco.cep || '').replace(/\D/g, ''),
        state_abbr: endereco.estado,
      },
      produtos: (itens as any[]).map(i => ({
        name: i.nome_produto, quantity: i.quantidade, unitary_value: Number(i.preco_unitario),
      })),
      volumes: [{ height: 10, width: 30, length: 20, weight: pesoTotal }],
      options: {
        insurance_value: Number(pedidoAny.subtotal) || 50,
        receipt: false, own_hand: false, non_commercial: true,
      },
    };

    // 3. Gera a etiqueta via Melhor Envio
    const { orderId, trackingCode, printUrl } = await gerarEtiquetaCompleta({
      token,
      userAgent: `${nomeLoja}/1.0 (${emailLoja})`,
      dados,
    });

    // 4. Salva no pedido
    await admin
      .from('pedidos')
      .update({
        codigo_rastreio: trackingCode,
        transportadora: 'Melhor Envio',
        melhorenvio_order_id: orderId,
        melhorenvio_print_url: printUrl,
        status: pedidoAny.status === 'pago' ? 'separando' : pedidoAny.status,
        updated_at: new Date().toISOString(),
      })
      .eq('id', pedidoId);

    return NextResponse.json({
      ok: true,
      trackingCode,
      printUrl,
      melhorenvioOrderId: orderId,
    });
  } catch (error: any) {
    console.error('[gerar-etiqueta]', error);
    return NextResponse.json({
      error: error?.message || 'Erro ao gerar etiqueta',
      detalhes: error?.response || null,
    }, { status: 500 });
  }
}
