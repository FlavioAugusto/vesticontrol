'use client';

import { useState, useEffect } from 'react';
import { createClient } from '@/lib/supabase/client';
import Input from '@/components/ui/Input';
import Button from '@/components/ui/Button';
import Toggle from '@/components/ui/Toggle';
import toast from 'react-hot-toast';

export default function PerfilPage() {
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    nome: '', sobrenome: '', telefone: '', whatsapp: '', cpf: '', newsletter: true,
  });

  useEffect(() => {
    const supabase = createClient();
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (!user) return;
      supabase.from('clientes').select('*').eq('id', user.id).single()
        .then(({ data }) => {
          if (data) {
            const c = data as typeof form & { nome: string; sobrenome: string | null; telefone: string | null; whatsapp: string | null; cpf: string | null; newsletter: boolean };
            setForm({
              nome: c.nome ?? '',
              sobrenome: c.sobrenome ?? '',
              telefone: c.telefone ?? '',
              whatsapp: c.whatsapp ?? '',
              cpf: c.cpf ?? '',
              newsletter: c.newsletter ?? true,
            });
          }
        });
    });
  }, []);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { toast.error('Faça login novamente'); setLoading(false); return; }

    const { error } = await supabase.from('clientes').upsert({
      id: user.id, ...form, updated_at: new Date().toISOString(),
    });

    setLoading(false);
    if (error) toast.error('Erro ao salvar: ' + error.message);
    else toast.success('Dados salvos com sucesso!');
  }

  return (
    <div>
      <h1 className="font-serif text-2xl text-charcoal mb-6">Meus Dados</h1>
      <div className="bg-white rounded-sm shadow-sm p-6">
        <form onSubmit={handleSave} className="space-y-4 max-w-lg">
          <div className="grid grid-cols-2 gap-4">
            <Input label="Nome" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} required />
            <Input label="Sobrenome" value={form.sobrenome} onChange={(e) => setForm({ ...form, sobrenome: e.target.value })} />
          </div>
          <Input label="CPF" placeholder="000.000.000-00" value={form.cpf} onChange={(e) => setForm({ ...form, cpf: e.target.value })} />
          <Input label="Telefone" placeholder="(81) 99999-9999" value={form.telefone} onChange={(e) => setForm({ ...form, telefone: e.target.value })} />
          <Input label="WhatsApp" placeholder="(81) 99999-9999" value={form.whatsapp} onChange={(e) => setForm({ ...form, whatsapp: e.target.value })} />
          <Toggle
            label="Receber novidades e promoções por e-mail"
            checked={form.newsletter}
            onChange={(v) => setForm({ ...form, newsletter: v })}
          />
          <Button type="submit" loading={loading}>Salvar Alterações</Button>
        </form>
      </div>
    </div>
  );
}
