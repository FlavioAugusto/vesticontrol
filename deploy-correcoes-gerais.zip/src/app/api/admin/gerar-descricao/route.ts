import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const { nome, categoria } = await req.json();

    // Descrição gerada com base nas informações do produto
    const templates = [
      `${nome} é uma peça sofisticada da coleção By Marcelo Medeiros. Confeccionada em tricoline 100% algodão, com modelagem premium que valoriza a silhueta feminina. Acabamento impecável com costuras reforçadas e tecido de alta qualidade. Ideal para eventos sociais, jantares e ocasiões especiais. Vendida individualmente — peça os tamanhos disponíveis acima.`,
      `Apresentamos o ${nome}, uma criação exclusiva da By Marcelo Medeiros diretamente do Polo de Confecções de Caruaru. Esta peça foi desenvolvida com tricoline 100% algodão de alta gramatura, garantindo conforto e durabilidade. O caimento valoriza todas as silhuetas, tornando-o perfeito para mulheres que desejam elegância no dia a dia e em ocasiões especiais.`,
      `O ${nome} é uma peça artesanal da coleção ${categoria ?? 'By Marcelo Medeiros'}. Produzido com matéria-prima selecionada — tricoline 100% algodão — e cuidadosamente confeccionado em nossa fábrica em Caruaru/PE. A modelagem premium e os detalhes refinados fazem desta peça uma escolha certeira para compor looks únicos e sofisticados.`,
    ];

    const idx = Math.floor(Math.random() * templates.length);
    return NextResponse.json({ descricao: templates[idx] });
  } catch {
    return NextResponse.json({ error: 'Erro ao gerar descrição' }, { status: 500 });
  }
}
