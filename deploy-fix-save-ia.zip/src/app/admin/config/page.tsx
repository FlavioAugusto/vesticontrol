'use client';

import { useState, useEffect } from 'react';
import { createClient } from '@/lib/supabase/client';
import Input from '@/components/ui/Input';
import Button from '@/components/ui/Button';
import Toggle from '@/components/ui/Toggle';
import toast from 'react-hot-toast';
import { Store, Truck, CreditCard, Image as ImageIcon, Globe, MessageCircle } from 'lucide-react';

interface Configs {
  loja_nome: string;
  loja_logo_url: string;
  loja_favicon_url: string;
  loja_email: string;
  loja_telefone: string;
  loja_whatsapp: string;
  loja_instagram: string;
  loja_cnpj: string;
  loja_horario_atendimento: string;
  topbar_texto: string;
  topbar_ativo: string;
  loja_cep_origem: string;
  frete_gratis_minimo: string;
  parcelas_sem_juros: string;
  rodape_texto: string;
  rodape_endereco: string;
  rodape_horario: string;
  rodape_rua: string;
  rodape_cnpj: string;
  rodape_credito: string;
  seo_titulo: string;
  seo_descricao: string;
}

const DEFAULTS: Configs = {
  loja_nome: '', loja_logo_url: '', loja_favicon_url: '',
  loja_email: '', loja_telefone: '', loja_whatsapp: '',
  loja_instagram: '', loja_cnpj: '', loja_horario_atendimento: '',
  topbar_texto: '', topbar_ativo: 'true',
  loja_cep_origem: '', frete_gratis_minimo: '',
  parcelas_sem_juros: '6',
  rodape_texto: '', rodape_endereco: '', rodape_horario: '',
  rodape_rua: '', rodape_cnpj: '', rodape_credito: '',
  seo_titulo: '', seo_descricao: '',
};

type ConfigKey = keyof Configs;

export default function AdminConfiguracoesPage() {
  const [configs, setConfigs] = useState<Configs>(DEFAULTS);
  const [loading, setLoading] = useState(false);
  const [aba, setAba] = useState<'identidade' | 'contato' | 'topbar' | 'frete' | 'rodape' | 'seo'>('identidade');
  const [lojaId, setLojaId] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const lojaRes = await fetch('/api/admin/minha-loja', { cache: 'no-store' });
        if (!lojaRes.ok) return;
        const lojaData = await lojaRes.json();
        const lid = lojaData.loja_id;
        if (!lid) return;
        setLojaId(lid);

        const supabase = createClient();
        const { data } = await supabase.from('configuracoes')
          .select('chave, valor')
          .eq('loja_id', lid);
        if (data && data.length > 0) {
          const obj = { ...DEFAULTS } as Record<string, string>;
          data.forEach((r: { chave: string; valor: string | null }) => {
            if (r.chave in obj) obj[r.chave] = r.valor ?? '';
          });
          setConfigs(obj as Configs);
        }
      } catch { /* usa defaults */ }
    })();
  }, []);

  function set(key: ConfigKey, value: string) {
    setConfigs(prev => ({ ...prev, [key]: value }));
  }

  async function salvar() {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/salvar-configs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ configs }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erro');
      toast.success('Configurações salvas!');
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Erro ao salvar');
    } finally {
      setLoading(false);
    }
  }

  const abas: { id: typeof aba; label: string; icon: React.ElementType }[] = [
    { id: 'identidade', label: 'Identidade', icon: Store },
    { id: 'contato', label: 'Contato', icon: MessageCircle },
    { id: 'topbar', label: 'TopBar', icon: ImageIcon },
    { id: 'frete', label: 'Frete', icon: Truck },
    { id: 'rodape', label: 'Rodapé', icon: Store },
    { id: 'seo', label: 'SEO', icon: Globe },
  ];

  return (
    <div className="max-w-4xl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl sm:text-2xl font-serif text-charcoal">Configurações</h1>
          <p className="text-gray-400 text-xs sm:text-sm mt-0.5">Personalize sua loja</p>
        </div>
        <Button onClick={salvar} loading={loading}>Salvar Tudo</Button>
      </div>

      {/* Abas */}
      <div className="flex flex-wrap gap-2 mb-5">
        {abas.map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => setAba(id)}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-semibold transition-colors rounded-lg ${aba === id ? 'bg-charcoal text-white' : 'bg-white text-charcoal-muted hover:bg-cream border border-cream-darker'}`}>
            <Icon size={14} /> {label}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-xl p-6 shadow-sm">
        {aba === 'identidade' && (
          <div className="space-y-4">
            <h2 className="font-serif text-lg text-charcoal mb-3">Identidade da Loja</h2>
            <Input label="Nome da Loja" value={configs.loja_nome} onChange={(e) => set('loja_nome', e.target.value)} placeholder="Ex: Minha Loja" />
            <Input label="URL do Logo" value={configs.loja_logo_url} onChange={(e) => set('loja_logo_url', e.target.value)} placeholder="https://..." />
            <Input label="URL do Favicon" value={configs.loja_favicon_url} onChange={(e) => set('loja_favicon_url', e.target.value)} placeholder="https://..." />
            <Input label="CNPJ" value={configs.loja_cnpj} onChange={(e) => set('loja_cnpj', e.target.value)} placeholder="00.000.000/0001-00" />
          </div>
        )}

        {aba === 'contato' && (
          <div className="space-y-4">
            <h2 className="font-serif text-lg text-charcoal mb-3">Contato</h2>
            <Input label="E-mail" value={configs.loja_email} onChange={(e) => set('loja_email', e.target.value)} placeholder="contato@sualoja.com.br" />
            <Input label="Telefone" value={configs.loja_telefone} onChange={(e) => set('loja_telefone', e.target.value)} placeholder="(11) 99999-9999" />
            <Input label="WhatsApp (só números)" value={configs.loja_whatsapp} onChange={(e) => set('loja_whatsapp', e.target.value)} placeholder="11999999999" />
            <Input label="Instagram (com @)" value={configs.loja_instagram} onChange={(e) => set('loja_instagram', e.target.value)} placeholder="@sualoja" />
            <Input label="Horário de Atendimento" value={configs.loja_horario_atendimento} onChange={(e) => set('loja_horario_atendimento', e.target.value)} placeholder="Seg–Sex: 9h–18h" />
          </div>
        )}

        {aba === 'topbar' && (
          <div className="space-y-4">
            <h2 className="font-serif text-lg text-charcoal mb-3">Faixa do Topo</h2>
            <Toggle label="Mostrar topbar" checked={configs.topbar_ativo !== 'false'} onChange={(c) => set('topbar_ativo', c ? 'true' : 'false')} />
            <Input label="Texto da topbar" value={configs.topbar_texto} onChange={(e) => set('topbar_texto', e.target.value)} placeholder="FRETE GRÁTIS ACIMA DE R$ 299" />
          </div>
        )}

        {aba === 'frete' && (
          <div className="space-y-4">
            <h2 className="font-serif text-lg text-charcoal mb-3">Frete</h2>
            <Input label="CEP de origem (sua loja)" value={configs.loja_cep_origem} onChange={(e) => set('loja_cep_origem', e.target.value)} placeholder="01000-000" />
            <Input label="Frete grátis acima de R$" value={configs.frete_gratis_minimo} onChange={(e) => set('frete_gratis_minimo', e.target.value)} placeholder="299.00" />
            <Input label="Parcelas sem juros" value={configs.parcelas_sem_juros} onChange={(e) => set('parcelas_sem_juros', e.target.value)} placeholder="6" />
          </div>
        )}

        {aba === 'rodape' && (
          <div className="space-y-4">
            <h2 className="font-serif text-lg text-charcoal mb-3">Rodapé</h2>
            <Input label="Texto do rodapé" value={configs.rodape_texto} onChange={(e) => set('rodape_texto', e.target.value)} placeholder="Moda feminina com qualidade." />
            <Input label="Endereço (cidade)" value={configs.rodape_endereco} onChange={(e) => set('rodape_endereco', e.target.value)} placeholder="Cidade — UF" />
            <Input label="Rua completa" value={configs.rodape_rua} onChange={(e) => set('rodape_rua', e.target.value)} placeholder="Rua X, 123 - Bairro" />
            <Input label="Horário" value={configs.rodape_horario} onChange={(e) => set('rodape_horario', e.target.value)} placeholder="Seg–Sex: 9h–18h" />
            <Input label="CNPJ (rodapé)" value={configs.rodape_cnpj} onChange={(e) => set('rodape_cnpj', e.target.value)} placeholder="00.000.000/0001-00" />
            <Input label="Crédito (linha final)" value={configs.rodape_credito} onChange={(e) => set('rodape_credito', e.target.value)} placeholder="Loja virtual desenvolvida com..." />
          </div>
        )}

        {aba === 'seo' && (
          <div className="space-y-4">
            <h2 className="font-serif text-lg text-charcoal mb-3">SEO</h2>
            <Input label="Título no Google" value={configs.seo_titulo} onChange={(e) => set('seo_titulo', e.target.value)} placeholder="Sua Loja — Moda Feminina" />
            <Input label="Descrição no Google" value={configs.seo_descricao} onChange={(e) => set('seo_descricao', e.target.value)} placeholder="Loja de moda feminina com peças exclusivas." />
          </div>
        )}
      </div>

      <div className="mt-5">
        <Button onClick={salvar} loading={loading} className="w-full">Salvar Configurações</Button>
      </div>
    </div>
  );
}
