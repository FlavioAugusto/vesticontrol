'use client';

import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Plus, Trash2, Palette, Check } from 'lucide-react';
import { CORES_PREDEFINIDAS } from '@/components/admin/ColorDropdown';

interface Cor { nome: string; hex: string }

function isRainbow(hex: string) { return hex === '#RAINBOW'; }
function corStyle(hex: string): React.CSSProperties {
  if (isRainbow(hex)) return { background: 'conic-gradient(red, yellow, lime, aqua, blue, magenta, red)' };
  return { backgroundColor: hex };
}

export default function AdminCoresPage() {
  const [cores, setCores] = useState<Cor[]>([]);
  const [loading, setLoading] = useState(true);
  const [novoNome, setNovoNome] = useState('');
  const [novoHex, setNovoHex] = useState('#B89155');
  const [salvando, setSalvando] = useState(false);

  useEffect(() => { carregar(); }, []);

  async function carregar() {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/cores');
      const data = await res.json();
      setCores(data);
    } catch { toast.error('Erro ao carregar cores'); }
    finally { setLoading(false); }
  }

  async function adicionar() {
    const nome = novoNome.trim();
    if (!nome) return;
    setSalvando(true);
    try {
      const res = await fetch('/api/admin/cores', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome, hex: novoHex }),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error || 'Erro ao salvar'); return; }
      setCores(data.cores);
      setNovoNome('');
      setNovoHex('#B89155');
      toast.success(`Cor "${nome}" adicionada!`);
    } catch { toast.error('Erro ao salvar'); }
    finally { setSalvando(false); }
  }

  async function remover(nome: string) {
    try {
      const res = await fetch('/api/admin/cores', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome }),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error || 'Erro ao remover'); return; }
      setCores(data.cores);
      toast.success(`Cor "${nome}" removida`);
    } catch { toast.error('Erro ao remover'); }
  }

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-serif text-charcoal tracking-tight">Cores Personalizadas</h1>
          <p className="text-gray-400 text-sm mt-1">Gerencie as cores disponíveis nas variantes dos produtos</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Formulário nova cor */}
        <div className="lg:col-span-1">
          <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm sticky top-24">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-9 h-9 rounded-xl bg-amber-50 flex items-center justify-center">
                <Plus size={16} className="text-gold" />
              </div>
              <div>
                <h2 className="font-semibold text-charcoal text-sm">Adicionar nova cor</h2>
                <p className="text-[11px] text-gray-400">Ficará disponível em todos os produtos</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider block mb-2">Selecionar cor</label>
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <input
                      type="color"
                      value={novoHex}
                      onChange={e => setNovoHex(e.target.value)}
                      className="w-14 h-14 rounded-xl border border-gray-200 cursor-pointer p-1 shadow-sm"
                    />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-charcoal">{novoHex.toUpperCase()}</p>
                    <p className="text-xs text-gray-400">Clique para alterar</p>
                  </div>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider block mb-2">Nome da cor</label>
                <input
                  type="text"
                  value={novoNome}
                  onChange={e => setNovoNome(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); adicionar(); } }}
                  placeholder="Ex: Fendi, Terracota, Marsala..."
                  className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-charcoal placeholder:text-gray-400 outline-none focus:border-gold/50 focus:ring-2 focus:ring-gold/10 transition-all"
                />
              </div>

              {/* Preview */}
              {novoNome && (
                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl border border-gray-100">
                  <div className="w-8 h-8 rounded-full border-2 border-white shadow-md flex-shrink-0" style={corStyle(novoHex)} />
                  <div>
                    <p className="text-sm font-semibold text-charcoal">{novoNome}</p>
                    <p className="text-[11px] text-gray-400">Preview da cor</p>
                  </div>
                </div>
              )}

              <button
                onClick={adicionar}
                disabled={!novoNome.trim() || salvando}
                className="w-full bg-gradient-to-r from-gold to-gold-600 text-white py-2.5 rounded-xl text-sm font-semibold hover:from-gold-600 hover:to-gold-700 transition-all shadow-md shadow-gold/20 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {salvando ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <><Plus size={14} /> Adicionar cor</>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Cores personalizadas */}
        <div className="lg:col-span-2 space-y-6">

          {/* Minhas cores */}
          <div className="bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-100 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gold/10 flex items-center justify-center">
                <Palette size={16} className="text-gold" />
              </div>
              <div>
                <h2 className="font-semibold text-charcoal text-sm">Minhas cores personalizadas</h2>
                <p className="text-[11px] text-gray-400">{cores.length} {cores.length === 1 ? 'cor adicionada' : 'cores adicionadas'}</p>
              </div>
            </div>

            {loading ? (
              <div className="py-12 text-center">
                <div className="w-6 h-6 border-2 border-gold/30 border-t-gold rounded-full animate-spin mx-auto mb-3" />
                <p className="text-gray-400 text-sm">Carregando...</p>
              </div>
            ) : cores.length === 0 ? (
              <div className="py-12 text-center">
                <Palette size={36} className="text-gray-200 mx-auto mb-3" />
                <p className="text-gray-400 text-sm font-medium">Nenhuma cor personalizada ainda</p>
                <p className="text-gray-300 text-xs mt-1">Use o formulário ao lado para adicionar</p>
              </div>
            ) : (
              <div className="divide-y divide-gray-50">
                {cores.map(c => (
                  <div key={c.nome} className="flex items-center gap-4 px-6 py-3.5 hover:bg-gray-50/60 transition-colors group">
                    <div className="w-10 h-10 rounded-xl border border-gray-200 flex-shrink-0 shadow-sm" style={corStyle(c.hex)} />
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-charcoal">{c.nome}</p>
                      <p className="text-[11px] text-gray-400 font-mono">{c.hex}</p>
                    </div>
                    <button
                      onClick={() => remover(c.nome)}
                      className="opacity-0 group-hover:opacity-100 w-8 h-8 flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Cores predefinidas (referência) */}
          <div className="bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-100">
              <h2 className="font-semibold text-charcoal text-sm">Cores predefinidas do sistema</h2>
              <p className="text-[11px] text-gray-400 mt-0.5">{CORES_PREDEFINIDAS.length} cores — sempre disponíveis, não podem ser removidas</p>
            </div>
            <div className="p-4 grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2">
              {CORES_PREDEFINIDAS.map(c => (
                <div key={c.nome} className="flex flex-col items-center gap-1.5 group cursor-default">
                  <div className="w-9 h-9 rounded-xl border border-gray-200 shadow-sm" style={corStyle(c.hex)} />
                  <span className="text-[9px] text-gray-400 text-center leading-tight line-clamp-2">{c.nome}</span>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
