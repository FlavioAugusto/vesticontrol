import { NextResponse } from 'next/server';
import { headers } from 'next/headers';
import { createClient as createServer } from '@/lib/supabase/server';
import { createClient as createAdmin } from '@/lib/supabase/admin';

const LOJA_DEFAULT = '00000000-0000-0000-0000-000000000001';

/**
 * GET /api/admin/configs-completas
 *
 * Retorna TODAS as configurações da loja (incluindo tokens/secrets).
 * 🔐 PROTEGIDO: só admin autenticado da loja correta acessa.
 *
 * O storefront público usa getConfiguracoes() que REMOVE chaves sensíveis.
 * Este endpoint é o ÚNICO jeito de admin recuperar tokens pra edição.
 */
export async function GET() {
  try {
    const server = createServer();
    const { data: { user } } = await server.auth.getUser();
    if (!user) {
      return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });
    }

    const admin = createAdmin();

    // Determina a loja do admin
    const { data: adminRow } = await admin.from('admins')
      .select('loja_id').eq('id', user.id).maybeSingle();
    const { data: superRow } = await admin.from('super_admins')
      .select('id').eq('id', user.id).maybeSingle();

    if (!adminRow && !superRow) {
      return NextResponse.json({ error: 'Sem permissão' }, { status: 403 });
    }

    // Super admin: pode pegar configs da loja do domínio atual
    // Admin normal: só da própria loja
    const lojaDoDominio = headers().get('x-loja-id') || LOJA_DEFAULT;
    const lojaId = superRow ? lojaDoDominio : (adminRow?.loja_id || LOJA_DEFAULT);

    const { data: configs } = await admin
      .from('configuracoes')
      .select('chave, valor')
      .eq('loja_id', lojaId);

    const result: Record<string, string> = {};
    (configs ?? []).forEach((c: { chave: string; valor: string | null }) => {
      result[c.chave] = c.valor ?? '';
    });

    return NextResponse.json(result, {
      headers: { 'Cache-Control': 'no-store, no-cache, must-revalidate' },
    });
  } catch (e) {
    return NextResponse.json({
      error: e instanceof Error ? e.message : 'Erro',
    }, { status: 500 });
  }
}
