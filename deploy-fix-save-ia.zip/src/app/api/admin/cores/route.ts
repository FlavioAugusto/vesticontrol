import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/admin';
import { createClient as createServer } from '@/lib/supabase/server';

const CHAVE = 'cores_personalizadas';
const LOJA_DEFAULT = '00000000-0000-0000-0000-000000000001';

async function getLojaIdDoAdmin(): Promise<string> {
  try {
    const s = createServer();
    const { data: { user } } = await s.auth.getUser();
    if (!user) return LOJA_DEFAULT;
    const a = createClient();
    const { data } = await a.from('admins').select('loja_id').eq('id', user.id).maybeSingle();
    return data?.loja_id || LOJA_DEFAULT;
  } catch { return LOJA_DEFAULT; }
}

export async function GET() {
  try {
    const lojaId = await getLojaIdDoAdmin();
    const supabase = createClient();
    const { data } = await supabase
      .from('configuracoes')
      .select('valor')
      .eq('chave', CHAVE)
      .eq('loja_id', lojaId)
      .maybeSingle();
    const cores = data?.valor ? JSON.parse(data.valor) : [];
    return NextResponse.json(cores);
  } catch {
    return NextResponse.json([]);
  }
}

export async function POST(req: NextRequest) {
  try {
    const { nome, hex } = await req.json();
    if (!nome || !hex) return NextResponse.json({ error: 'Nome e hex obrigatórios' }, { status: 400 });

    const lojaId = await getLojaIdDoAdmin();
    const supabase = createClient();

    const { data } = await supabase
      .from('configuracoes')
      .select('valor')
      .eq('chave', CHAVE)
      .eq('loja_id', lojaId)
      .maybeSingle();

    const cores: { nome: string; hex: string }[] = data?.valor ? JSON.parse(data.valor) : [];
    if (cores.some(c => c.nome.toLowerCase() === nome.toLowerCase())) {
      return NextResponse.json({ error: 'Cor já existe' }, { status: 409 });
    }
    cores.push({ nome: nome.trim(), hex });

    const { error } = await supabase.from('configuracoes').upsert({
      chave: CHAVE,
      loja_id: lojaId,
      valor: JSON.stringify(cores),
      tipo: 'text',
      grupo: 'cores',
      updated_at: new Date().toISOString(),
    }, { onConflict: 'chave,loja_id' });

    if (error) {
      return NextResponse.json({ error: `Erro ao salvar: ${error.message}` }, { status: 500 });
    }

    return NextResponse.json({ ok: true, cores });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { nome } = await req.json();
    const lojaId = await getLojaIdDoAdmin();
    const supabase = createClient();

    const { data } = await supabase
      .from('configuracoes')
      .select('valor')
      .eq('chave', CHAVE)
      .eq('loja_id', lojaId)
      .maybeSingle();

    const cores: { nome: string; hex: string }[] = data?.valor ? JSON.parse(data.valor) : [];
    const updated = cores.filter(c => c.nome !== nome);

    const { error } = await supabase.from('configuracoes').upsert({
      chave: CHAVE,
      loja_id: lojaId,
      valor: JSON.stringify(updated),
      tipo: 'text',
      grupo: 'cores',
      updated_at: new Date().toISOString(),
    }, { onConflict: 'chave,loja_id' });

    if (error) {
      return NextResponse.json({ error: `Erro ao salvar: ${error.message}` }, { status: 500 });
    }

    return NextResponse.json({ ok: true, cores: updated });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
