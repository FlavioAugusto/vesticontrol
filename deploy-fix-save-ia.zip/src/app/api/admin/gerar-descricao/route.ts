import { NextRequest, NextResponse } from 'next/server';
import { headers } from 'next/headers';
import { createClient } from '@/lib/supabase/admin';

const LOJA_DEFAULT = '00000000-0000-0000-0000-000000000001';

/**
 * Gera descrição de produto com foco em CONVERSÃO:
 * - Headline impactante
 * - Benefícios (não só features)
 * - Senso de urgência
 * - Call to action
 * - Multi-tenant (usa nome da loja do request)
 */
export async function POST(req: NextRequest) {
  try {
    const { nome, categoria, composicao } = await req.json();
    if (!nome) {
      return NextResponse.json({ error: 'Nome do produto obrigatório' }, { status: 400 });
    }

    // Detecta a loja pra personalizar
    const lojaId = headers().get('x-loja-id') || LOJA_DEFAULT;
    const supabase = createClient();
    const { data: configsLoja } = await supabase
      .from('configuracoes')
      .select('chave, valor')
      .eq('loja_id', lojaId)
      .in('chave', ['loja_nome', 'parcelas_sem_juros']);

    const cfg: Record<string, string> = {};
    (configsLoja ?? []).forEach((c: { chave: string; valor: string }) => { cfg[c.chave] = c.valor; });

    const nomeLoja = cfg.loja_nome || 'Nossa Loja';
    const parcelas = cfg.parcelas_sem_juros || '6';
    const composicaoFinal = composicao || 'tecido nobre selecionado';
    const categoriaFinal = categoria || 'coleção';

    const templates = [
      // Template 1: Emocional + benefícios
      `✨ ${nome} — a peça que vai transformar o seu look\n\n${nome} foi criada para mulheres que sabem que ELEGÂNCIA é detalhe. Cada costura, cada caimento, cada acabamento pensado pra você se sentir poderosa onde quer que vá.\n\n💎 POR QUE ESCOLHER ESSA PEÇA:\n• Modelagem que VALORIZA a silhueta (não importa seu biotipo)\n• ${composicaoFinal} — conforto que dura o dia todo\n• Acabamento premium, costuras reforçadas\n• Versátil: trabalho, jantar, eventos — vai com tudo\n\n🎁 BENEFÍCIOS EXCLUSIVOS:\n✓ Parcelamento em até ${parcelas}x SEM JUROS\n✓ Garantia de qualidade ${nomeLoja}\n✓ Trocas facilitadas em até 7 dias\n\n⚡ Atenção: estoque limitado por tamanho. Garanta o seu antes que acabe!`,

      // Template 2: Conexão pessoal
      `${nome} 💕\n\nLembra daquele dia que você procurou no guarda-roupa e não achou NADA pra vestir? Pois é, ${nome} resolveu esse problema.\n\nUma peça versátil, super confortável e que ainda te deixa com aquele ar de "como ela faz pra estar sempre arrumada?". Spoiler: o segredo está nos detalhes.\n\n🌟 O QUE TORNA ESPECIAL:\n• Tecido: ${composicaoFinal} — respira, não amassa fácil\n• Modelagem: pensada pra mulher real\n• Estilo: clean, sofisticado, atemporal\n\n💳 Você pode parcelar em ${parcelas}x sem juros — é dar play no seu cartão e pronto.\n\nProdução LIMITADA — quando acaba o estoque, acabou. Aproveita enquanto tem o seu tamanho disponível 🛒`,

      // Template 3: Direto + features
      `🛍️ ${nome} — ${categoriaFinal} ${nomeLoja}\n\n${nome} é o tipo de peça que toda mulher precisa ter no guarda-roupa. Versatilidade, qualidade e elegância em uma única escolha.\n\n📐 DETALHES TÉCNICOS:\n• Composição: ${composicaoFinal}\n• Modelagem premium\n• Acabamento profissional\n• Disponível em vários tamanhos\n\n💰 CONDIÇÕES ESPECIAIS:\n• Parcelamento: até ${parcelas}x sem juros no cartão\n• PIX: desconto adicional\n• Frete grátis acima do valor mínimo\n\n🚀 GARANTIA DE SATISFAÇÃO:\nSe não amar, você troca em até 7 dias úteis.\n\n⏰ Estoque limitado por tamanho — corre antes que acabe!`,

      // Template 4: Storytelling
      `${nome} — feita pra você brilhar ✨\n\nTem peças que ficam no armário esperando "uma ocasião especial". E tem peças que CRIAM ocasiões especiais. ${nome} é dessas.\n\nFoi pensada pra mulher que não espera permissão pra se sentir linda. Pra ser usada num almoço de domingo, num jantar romântico, num evento de trabalho — ou só porque você quer.\n\n💫 O QUE TE FAZ AMAR:\n→ ${composicaoFinal}: confortável até quando você senta no sofá\n→ Caimento perfeito que abraça e valoriza\n→ Combinação fácil — vai com peças que você JÁ TEM\n→ Tendência atemporal — não sai de moda no próximo verão\n\n🛒 COMPRE AGORA:\n• Em até ${parcelas}x sem juros no cartão\n• Com desconto especial no PIX\n• Receba em casa com segurança\n\n📦 Despache em até 24h úteis. Estoque LIMITADO por tamanho.`,
    ];

    const idx = Math.floor(Math.random() * templates.length);
    return NextResponse.json({
      descricao: templates[idx],
      template: idx + 1,
    });
  } catch (e) {
    return NextResponse.json({
      error: e instanceof Error ? e.message : 'Erro ao gerar descrição',
    }, { status: 500 });
  }
}
