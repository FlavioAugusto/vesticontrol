import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/admin';

// Guias são armazenados como JSON na tabela configuracoes
const CHAVE = 'guias_tamanhos';

const GUIA_PADRAO = [
  {
    id: 'vestidos',
    nome: 'Guia de Vestidos e Conjuntos',
    medidas: [
      { label: 'Busto', P: '88-92 cm', M: '92-96 cm', G: '96-100 cm' },
      { label: 'Cintura', P: '70-74 cm', M: '74-78 cm', G: '78-82 cm' },
      { label: 'Quadril', P: '94-98 cm', M: '98-102 cm', G: '102-106 cm' },
      { label: 'Comprimento', P: '100-102 cm', M: '102-104 cm', G: '104-106 cm' },
    ],
    imagem_url: '',
    dica: 'Meça em centímetros com a fita bem ajustada ao corpo.',
  },
];

export async function GET() {
  try {
    const supabase = createClient();
    const { data } = await supabase.from('configuracoes').select('valor').eq('chave', CHAVE).single();
    const guias = data?.valor ? JSON.parse(data.valor) : GUIA_PADRAO;
    return NextResponse.json(guias);
  } catch {
    return NextResponse.json(GUIA_PADRAO);
  }
}

export async function POST(req: NextRequest) {
  try {
    const guias = await req.json();
    const supabase = createClient();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (supabase.from('configuracoes') as any).upsert({
      chave: CHAVE, valor: JSON.stringify(guias), grupo: 'tamanhos',
    });
    return NextResponse.json({ ok: true });
  } catch (error: unknown) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Erro' }, { status: 500 });
  }
}
