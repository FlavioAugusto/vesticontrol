import { NextResponse } from 'next/server';
import { createClient as createServer } from '@/lib/supabase/server';
import { createClient as createAdmin } from '@/lib/supabase/admin';

/**
 * Retorna o loja_id do admin logado.
 * Usado pelos painéis admin pra filtrar queries por loja.
 *
 * Super_admin sem loja específica recebe o loja default (00000...0001).
 */
export async function GET() {
  try {
    const server = createServer();
    const { data: { user } } = await server.auth.getUser();
    if (!user) {
      return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });
    }

    const admin = createAdmin();

    // 1. Tenta como admin
    const { data: adminRow } = await admin.from('admins')
      .select('loja_id, nivel, nome')
      .eq('id', user.id)
      .maybeSingle();

    if (adminRow?.loja_id) {
      const { data: loja } = await admin.from('lojas')
        .select('id, nome, slug, dominio').eq('id', adminRow.loja_id).maybeSingle();
      return NextResponse.json({
        loja_id: adminRow.loja_id,
        loja: loja,
        nivel: adminRow.nivel,
        eh_super_admin: false,
      }, { headers: { 'Cache-Control': 'no-store' } });
    }

    // 2. Se for super_admin sem registro em admins, retorna loja default
    const { data: sup } = await admin.from('super_admins').select('id').eq('id', user.id).maybeSingle();
    if (sup) {
      const LOJA_DEFAULT = '00000000-0000-0000-0000-000000000001';
      const { data: loja } = await admin.from('lojas')
        .select('id, nome, slug, dominio').eq('id', LOJA_DEFAULT).maybeSingle();
      return NextResponse.json({
        loja_id: LOJA_DEFAULT,
        loja: loja,
        nivel: 'super',
        eh_super_admin: true,
      }, { headers: { 'Cache-Control': 'no-store' } });
    }

    return NextResponse.json({ error: 'Usuário sem permissão' }, { status: 403 });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : 'Erro' }, { status: 500 });
  }
}
