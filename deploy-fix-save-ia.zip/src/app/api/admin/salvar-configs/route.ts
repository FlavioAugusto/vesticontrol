import { NextRequest, NextResponse } from 'next/server';
import { revalidatePath } from 'next/cache';
import { headers } from 'next/headers';
import { createClient } from '@/lib/supabase/admin';
import { createClient as createServer } from '@/lib/supabase/server';

const LOJA_DEFAULT = '00000000-0000-0000-0000-000000000001';

/**
 * Resolve qual loja_id usar pra salvar configs.
 *
 * REGRA:
 * 1. Prioriza o `x-loja-id` do middleware (loja do DOMÍNIO acessado)
 * 2. Se for super_admin: pode salvar em qualquer loja (usa header se houver, senão default)
 * 3. Se for admin normal: PRECISA bater com o loja_id do registro em admins (segurança)
 */
/**
 * Resolve qual loja_id usar:
 * - Se cliente passar `loja_id` explícito → usa esse (mas valida permissão)
 * - Senão usa loja do admin logado
 *
 * REGRAS DE PERMISSÃO:
 * - Super admin: pode salvar em QUALQUER loja
 * - Admin normal: só pode salvar na própria loja
 */
async function resolverLojaId(lojaIdRequest?: string): Promise<{ lojaId: string; erro?: string }> {
  try {
    const s = createServer();
    const { data: { user } } = await s.auth.getUser();
    if (!user) return { lojaId: LOJA_DEFAULT, erro: 'Não autenticado' };

    const a = createClient();

    // Verifica se é super_admin
    const { data: sup } = await a.from('super_admins').select('id').eq('id', user.id).maybeSingle();

    // Pega loja do admin
    const { data: admin } = await a.from('admins').select('loja_id').eq('id', user.id).maybeSingle();

    // Determina a loja final
    const lojaSolicitada = lojaIdRequest || admin?.loja_id || headers().get('x-loja-id') || LOJA_DEFAULT;

    if (sup) {
      // Super admin: pode salvar em qualquer loja, valida que loja existe
      const { data: lojaExiste } = await a.from('lojas').select('id').eq('id', lojaSolicitada).maybeSingle();
      if (!lojaExiste) {
        return { lojaId: LOJA_DEFAULT, erro: 'Loja não encontrada' };
      }
      return { lojaId: lojaSolicitada };
    }

    if (!admin?.loja_id) return { lojaId: LOJA_DEFAULT, erro: 'Sem permissão' };

    // Admin normal: bloqueia se tentar salvar em loja diferente da dele
    if (lojaSolicitada !== admin.loja_id) {
      return {
        lojaId: admin.loja_id,
        erro: '⚠️ Você não tem permissão para editar essa loja.',
      };
    }

    return { lojaId: admin.loja_id };
  } catch { return { lojaId: LOJA_DEFAULT }; }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const configs = body?.configs;
    const lojaIdRequest = body?.loja_id as string | undefined;

    if (!configs || typeof configs !== 'object') {
      return NextResponse.json({ error: 'Payload inválido' }, { status: 400 });
    }

    const supabase = createClient();

    // Verificar conexão
    const { error: pingErr } = await supabase.from('configuracoes').select('chave').limit(1);
    if (pingErr) {
      return NextResponse.json({ error: `Conexão Supabase: ${pingErr.message}` }, { status: 503 });
    }

    // 🛡️ Multi-tenant: cliente envia loja_id, API valida permissão
    const { lojaId: LOJA_ID, erro: erroLoja } = await resolverLojaId(lojaIdRequest);
    if (erroLoja) {
      return NextResponse.json({ error: erroLoja, code: 'WRONG_LOJA' }, { status: 403 });
    }

    const entries = Object.entries(configs as Record<string, string>)
      .filter(([k, v]) => k && v !== undefined && v !== null);

    const rows = entries.map(([chave, valor]) => ({
      chave: String(chave),
      loja_id: LOJA_ID,
      valor: String(valor ?? ''),
      tipo: 'text',
      grupo: resolverGrupo(chave),
      updated_at: new Date().toISOString(),
    }));

    // Salvar em lotes de 5 com upsert na chave composta (chave, loja_id)
    for (let i = 0; i < rows.length; i += 5) {
      const batch = rows.slice(i, i + 5);
      const { error } = await supabase
        .from('configuracoes')
        .upsert(batch, { onConflict: 'chave,loja_id' });

      if (error) {
        return NextResponse.json({
          error: `Erro ao salvar lote ${i}-${i + 5}: ${error.message}`,
          code: error.code,
        }, { status: 500 });
      }
    }

    // Invalida cache de todas as rotas (favicon, título, logo, etc atualizam imediatamente)
    try {
      revalidatePath('/', 'layout');
    } catch { /* ignora se falhar */ }

    return NextResponse.json({ ok: true, total: rows.length });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Erro interno';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

function resolverGrupo(chave: string): string {
  if (chave.startsWith('hero') || chave.startsWith('banner') || chave.startsWith('slide')) return 'hero';
  if (chave.startsWith('trust')) return 'trustbar';
  if (chave.startsWith('secao')) return 'secoes';
  if (chave.startsWith('quem')) return 'quemsomos';
  if (chave.startsWith('newsletter')) return 'newsletter';
  if (chave.startsWith('rodape')) return 'rodape';
  if (chave.startsWith('loja') || chave.startsWith('topbar')) return 'loja';
  if (chave.startsWith('modal')) return 'modais';
  if (chave.startsWith('depoimentos')) return 'depoimentos';
  if (chave.startsWith('pagamento') || chave.startsWith('mercado') || chave.startsWith('infinite') || chave.startsWith('gateway') || chave.startsWith('asaas') || chave.startsWith('pagarme') || chave.startsWith('parcelas')) return 'pagamento';
  if (chave.startsWith('frete') || chave.startsWith('melhor') || chave.startsWith('correios')) return 'frete';
  if (chave.startsWith('seo')) return 'seo';
  return 'geral';
}
