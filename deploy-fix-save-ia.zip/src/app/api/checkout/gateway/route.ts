import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/admin';

export async function GET() {
  try {
    const supabase = createClient();
    const { data: configs } = await supabase
      .from('configuracoes')
      .select('chave, valor')
      .in('chave', [
        'gateway_pagamento', 'infinitepay_ativo', 'mercadopago_ativo', 'infinitepay_handle',
        'pagamento_pix_ativo', 'pagamento_boleto_ativo', 'pagamento_pix_desconto', 'parcelas_max',
      ]);

    const map: Record<string, string> = {};
    (configs ?? []).forEach((c: { chave: string; valor: string }) => { map[c.chave] = c.valor; });

    const gateway = map.gateway_pagamento || (map.infinitepay_ativo === 'true' ? 'infinitepay' : 'mercadopago');
    const mpPublicKey = process.env.NEXT_PUBLIC_MERCADOPAGO_PUBLIC_KEY || '';
    const infinitepayHandle = map.infinitepay_handle || process.env.INFINITEPAY_HANDLE || '';

    return NextResponse.json({
      gateway,
      mp_public_key: mpPublicKey,
      mp_disponivel: !!mpPublicKey && !mpPublicKey.includes('...'),
      infinitepay_disponivel: !!infinitepayHandle,
      pix_ativo: map.pagamento_pix_ativo !== 'false',  // default true
      boleto_ativo: map.pagamento_boleto_ativo !== 'false',  // default true
      pix_desconto: parseInt(map.pagamento_pix_desconto ?? '15') || 15,
      parcelas_max: parseInt(map.parcelas_max ?? '6') || 6,
    });
  } catch (e: any) {
    return NextResponse.json({
      gateway: 'infinitepay',
      mp_disponivel: false,
      infinitepay_disponivel: !!process.env.INFINITEPAY_HANDLE,
    });
  }
}
