import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

// Cache de 60 segundos para configs públicas
export const revalidate = 60;

export async function GET() {
  try {
    const supabase = createClient();
    const { data } = await supabase
      .from('configuracoes')
      .select('chave, valor')
      .in('chave', ['loja_logo_url', 'loja_nome', 'loja_telefone', 'loja_horario_atendimento', 'loja_email', 'loja_whatsapp']);

    const c: Record<string, string> = {};
    (data ?? []).forEach((r: { chave: string; valor: string | null }) => {
      c[r.chave] = r.valor ?? '';
    });

    return NextResponse.json({
      logo: c.loja_logo_url || '/images/logo.svg',
      nome: c.loja_nome || 'By Marcelo Medeiros',
      telefone: c.loja_telefone || '(81) 99422-8240',
      horario: c.loja_horario_atendimento || 'Seg–Sex: 08:00–18:00',
      email: c.loja_email || '',
      whatsapp: c.loja_whatsapp || '81994228240',
    }, {
      headers: { 'Cache-Control': 'public, s-maxage=60, stale-while-revalidate=120' }
    });
  } catch {
    return NextResponse.json({
      logo: '/images/logo.svg',
      nome: 'By Marcelo Medeiros',
      telefone: '(81) 99422-8240',
      horario: 'Seg–Sex: 08:00–18:00',
      email: '',
      whatsapp: '81994228240',
    });
  }
}
