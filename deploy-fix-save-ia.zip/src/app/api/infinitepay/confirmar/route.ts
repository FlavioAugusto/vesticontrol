import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/admin';
import { checkPayment } from '@/lib/infinitepay';
import { headers } from 'next/headers';

export async function POST(req: NextRequest) {
  try {
    const { pedidoId, transaction_nsu, slug, capture_method } = await req.json();
    if (!pedidoId) return NextResponse.json({ error: 'pedidoId obrigatório' }, { status: 400 });

    const supabase = createClient();
    const lojaId = headers().get('x-loja-id') || '00000000-0000-0000-0000-000000000001';

    const { data: configHandle } = await supabase.from('configuracoes')
      .select('valor').eq('chave', 'infinitepay_handle').eq('loja_id', lojaId).maybeSingle();
    const handle = configHandle?.valor || process.env.INFINITEPAY_HANDLE;
    if (!handle) return NextResponse.json({ ok: true });

    const result = await checkPayment({
      handle,
      order_nsu: pedidoId,
      transaction_nsu: transaction_nsu || undefined,
      slug: slug || undefined,
    });

    if (result.paid) {
      await supabase.from('pedidos').update({
        status_pagamento: 'approved',
        status: 'pago',
        payment_id: transaction_nsu || slug || null,
        metodo_pagamento: `infinitepay_${capture_method || 'checkout'}`,
        pago_em: new Date().toISOString(),
      }).eq('id', pedidoId);
    }

    return NextResponse.json({ ok: true, paid: result.paid });
  } catch (error: unknown) {
    console.error('[InfinitePay Confirmar]', error);
    return NextResponse.json({ ok: true });
  }
}
