import { NextRequest, NextResponse } from 'next/server';
import { createClient as createServer } from '@/lib/supabase/server';
import { createClient as createAdmin } from '@/lib/supabase/admin';
import { TEMPLATE_CATEGORIAS, TEMPLATE_PRODUTOS, TEMPLATE_CONFIGS } from '@/lib/template-demo';

/**
 * Aplica template em loja JÁ EXISTENTE (não duplica, só adiciona o que faltar).
 */
export async function POST(req: NextRequest) {
  try {
    const server = createServer();
    const { data: { user } } = await server.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });

    const admin = createAdmin();
    const { data: ehSuper } = await admin.from('super_admins').select('id').eq('id', user.id).maybeSingle();
    if (!ehSuper) return NextResponse.json({ error: 'Acesso negado' }, { status: 403 });

    const { loja_id, forcar } = await req.json();
    if (!loja_id) return NextResponse.json({ error: 'loja_id obrigatório' }, { status: 400 });

    const { data: loja } = await admin.from('lojas').select('*').eq('id', loja_id).maybeSingle();
    if (!loja) return NextResponse.json({ error: 'Loja não encontrada' }, { status: 404 });

    // 🛡️ Bloqueio: loja com >5 produtos é considerada em produção
    const { count: produtosExistentes } = await admin
      .from('produtos').select('*', { count: 'exact', head: true }).eq('loja_id', loja_id);

    if ((produtosExistentes ?? 0) > 5 && !forcar) {
      return NextResponse.json({
        error: `A loja "${loja.nome}" já tem ${produtosExistentes} produtos cadastrados.`,
        code: 'LOJA_EM_PRODUCAO',
        produtos_existentes: produtosExistentes,
      }, { status: 403 });
    }

    const resultado = { categorias: 0, produtos: 0, configs: 0, ja_existiam: { categorias: 0, produtos: 0, configs: 0 } };

    // Configs (só insere os que faltam)
    const configsObj = TEMPLATE_CONFIGS(loja);
    const configRows = Object.entries(configsObj).map(([chave, valor]) => ({
      chave, valor: String(valor), loja_id, tipo: 'text', grupo: 'geral',
    }));
    const { data: cfgExistentes } = await admin.from('configuracoes')
      .select('chave').eq('loja_id', loja_id);
    const chavesExistentes = new Set((cfgExistentes ?? []).map((c: { chave: string }) => c.chave));
    const configsNovas = configRows.filter(c => !chavesExistentes.has(c.chave));
    resultado.ja_existiam.configs = configRows.length - configsNovas.length;
    if (configsNovas.length > 0) {
      const { error } = await admin.from('configuracoes').insert(configsNovas);
      if (!error) resultado.configs = configsNovas.length;
    }

    // Categorias (skip se já existir slug)
    const { data: catsExistentes } = await admin.from('categorias')
      .select('slug').eq('loja_id', loja_id);
    const slugsExistentes = new Set((catsExistentes ?? []).map((c: { slug: string }) => c.slug));

    const catsParaInserir = TEMPLATE_CATEGORIAS
      .map(c => ({ ...c, slug: `${c.slug}-${loja.slug}`, ativo: true, loja_id }))
      .filter(c => !slugsExistentes.has(c.slug));
    resultado.ja_existiam.categorias = TEMPLATE_CATEGORIAS.length - catsParaInserir.length;

    if (catsParaInserir.length > 0) {
      const { data } = await admin.from('categorias').insert(catsParaInserir).select();
      resultado.categorias = (data ?? []).length;
    }

    const { data: todasCatsLoja } = await admin.from('categorias')
      .select('id, slug').eq('loja_id', loja_id);
    const catsBySlug = new Map(
      (todasCatsLoja ?? []).map((c: { id: string; slug: string }) =>
        [c.slug.replace(`-${loja.slug}`, ''), c.id]
      )
    );

    // Produtos
    const { data: prodsExistentes } = await admin.from('produtos')
      .select('slug').eq('loja_id', loja_id);
    const prodSlugsExistentes = new Set((prodsExistentes ?? []).map((p: { slug: string }) => p.slug));

    for (const p of TEMPLATE_PRODUTOS) {
      const slugFinal = `${p.slug}-${loja.slug}`;
      if (prodSlugsExistentes.has(slugFinal)) {
        resultado.ja_existiam.produtos += 1;
        continue;
      }

      const catId = catsBySlug.get(p.categoria_slug);
      const { data: produto } = await admin.from('produtos').insert({
        nome: p.nome, slug: slugFinal, descricao: p.descricao,
        preco: p.preco, preco_antigo: p.preco_antigo ?? null,
        badge: p.badge ?? null, destaque: p.destaque, ativo: true,
        peso_gramas: 500, categoria_id: catId, loja_id,
      }).select().single();

      if (produto) {
        await admin.from('produto_imagens').insert({
          produto_id: produto.id, url: p.imagem, ordem: 0, principal: true, loja_id,
        });
        await admin.from('produto_variantes').insert([
          { produto_id: produto.id, tamanho: 'P', cor: 'Único', estoque: 10, loja_id },
          { produto_id: produto.id, tamanho: 'M', cor: 'Único', estoque: 10, loja_id },
          { produto_id: produto.id, tamanho: 'G', cor: 'Único', estoque: 10, loja_id },
        ]);
        resultado.produtos += 1;
      }
    }

    return NextResponse.json({
      ok: true,
      mensagem: `Template aplicado! +${resultado.categorias} categoria(s), +${resultado.produtos} produto(s), +${resultado.configs} config(s)`,
      resultado,
    });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : 'Erro' }, { status: 500 });
  }
}
