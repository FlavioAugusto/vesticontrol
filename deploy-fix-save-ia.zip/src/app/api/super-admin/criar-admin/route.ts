import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/admin';

export async function POST(req: NextRequest) {
  try {
    const { nome, email, senha, loja_id } = await req.json();

    if (!nome || !email || !senha || !loja_id) {
      return NextResponse.json({ error: 'Nome, email, senha e loja são obrigatórios' }, { status: 400 });
    }
    if (senha.length < 6) {
      return NextResponse.json({ error: 'Senha deve ter no mínimo 6 caracteres' }, { status: 400 });
    }

    const supabase = createClient();

    // 1. Verifica se loja existe
    const { data: loja } = await supabase.from('lojas').select('id, nome').eq('id', loja_id).maybeSingle();
    if (!loja) return NextResponse.json({ error: 'Loja não encontrada' }, { status: 404 });

    // 2. Verifica se usuário já existe no auth
    const { data: existentes } = await supabase.auth.admin.listUsers();
    const jaExiste = existentes?.users?.find(u => u.email === email);

    let userId: string;

    if (jaExiste) {
      // Usuário já tem conta — só adiciona como admin
      userId = jaExiste.id;
    } else {
      // Cria novo usuário no Supabase Auth
      const { data: novoUser, error: errUser } = await supabase.auth.admin.createUser({
        email,
        password: senha,
        email_confirm: true, // confirma email automaticamente
        user_metadata: { full_name: nome },
      });
      if (errUser || !novoUser.user) {
        return NextResponse.json({ error: errUser?.message || 'Erro ao criar usuário' }, { status: 500 });
      }
      userId = novoUser.user.id;
    }

    // 3. Adiciona na tabela admins vinculado à loja
    const { error: errAdmin } = await supabase.from('admins').upsert({
      id: userId,
      nome,
      nivel: 'admin',
      loja_id,
    }, { onConflict: 'id' });

    if (errAdmin) {
      return NextResponse.json({ error: errAdmin.message }, { status: 500 });
    }

    return NextResponse.json({
      ok: true,
      usuario: { id: userId, email, nome },
      loja: loja,
      ja_existia: !!jaExiste,
      mensagem: jaExiste
        ? `${email} já tinha conta — agora é admin da loja "${loja.nome}"`
        : `Admin criado com sucesso! Email: ${email}`,
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  const lojaId = req.nextUrl.searchParams.get('loja_id');
  if (!lojaId) return NextResponse.json({ error: 'loja_id obrigatório' }, { status: 400 });

  try {
    const supabase = createClient();
    const { data } = await supabase
      .from('admins')
      .select('id, nome, nivel, created_at')
      .eq('loja_id', lojaId);

    // Busca emails de cada admin
    const { data: users } = await supabase.auth.admin.listUsers();
    const adminsComEmail = (data ?? []).map((a: { id: string; nome: string; nivel: string; created_at: string }) => {
      const user = users?.users?.find(u => u.id === a.id);
      return { ...a, email: user?.email ?? '—' };
    });

    return NextResponse.json(adminsComEmail);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { admin_id, loja_id } = await req.json();
    if (!admin_id || !loja_id) return NextResponse.json({ error: 'admin_id e loja_id obrigatórios' }, { status: 400 });

    const supabase = createClient();
    await supabase.from('admins').delete().eq('id', admin_id).eq('loja_id', loja_id);

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/**
 * PATCH /api/super-admin/criar-admin
 * Edita um admin existente: nome, email ou senha.
 */
export async function PATCH(req: NextRequest) {
  try {
    const { admin_id, loja_id, nome, email, senha } = await req.json();
    if (!admin_id) return NextResponse.json({ error: 'admin_id obrigatório' }, { status: 400 });

    const supabase = createClient();

    // Atualiza nome na tabela admins (se foi enviado)
    if (nome) {
      const filter = supabase.from('admins').update({ nome }).eq('id', admin_id);
      if (loja_id) filter.eq('loja_id', loja_id);
      await filter;
    }

    // Atualiza email e/ou senha no auth.users via service role
    const updates: { email?: string; password?: string } = {};
    if (email) updates.email = email;
    if (senha) {
      if (senha.length < 6) {
        return NextResponse.json({ error: 'Senha deve ter no mínimo 6 caracteres' }, { status: 400 });
      }
      updates.password = senha;
    }

    if (Object.keys(updates).length > 0) {
      const { error } = await supabase.auth.admin.updateUserById(admin_id, updates);
      if (error) {
        return NextResponse.json({ error: `Erro ao atualizar: ${error.message}` }, { status: 500 });
      }
    }

    return NextResponse.json({
      ok: true,
      mensagem: senha ? 'Admin atualizado (senha alterada)' : 'Admin atualizado',
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
