import { NextRequest, NextResponse } from 'next/server';
import { createClient as createServer } from '@/lib/supabase/server';
import { createClient as createAdmin } from '@/lib/supabase/admin';
import { TEMPLATE_CATEGORIAS, TEMPLATE_PRODUTOS, TEMPLATE_CONFIGS } from '@/lib/template-demo';

/**
 * Cria uma nova loja completa: loja + admin + dados de template demo.
 */
export async function POST(req: NextRequest) {
  try {
    const server = createServer();
    const { data: { user } } = await server.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });

    const admin = createAdmin();
    const { data: ehSuper } = await admin.from('super_admins').select('id').eq('id', user.id).maybeSingle();
    if (!ehSuper) return NextResponse.json({ error: 'Acesso negado — apenas super_admin' }, { status: 403 });

    const body = await req.json();
    const { loja, admin: adminInput, incluirTemplate = true } = body;

    if (!loja?.nome || !loja?.slug || !loja?.email_admin) {
      return NextResponse.json({ error: 'Loja: nome, slug e email_admin são obrigatórios' }, { status: 400 });
    }
    if (!adminInput?.nome || !adminInput?.email || !adminInput?.senha) {
      return NextResponse.json({ error: 'Admin: nome, email e senha são obrigatórios' }, { status: 400 });
    }
    if (adminInput.senha.length < 6) {
      return NextResponse.json({ error: 'Senha deve ter no mínimo 6 caracteres' }, { status: 400 });
    }

    // Verifica slug
    const { data: lojaExistente } = await admin.from('lojas').select('id').eq('slug', loja.slug).maybeSingle();
    if (lojaExistente) {
      return NextResponse.json({ error: `Slug "${loja.slug}" já está em uso` }, { status: 409 });
    }

    // Cria loja
    const { data: novaLoja, error: lojaErr } = await admin.from('lojas').insert({
      nome: loja.nome,
      slug: loja.slug,
      dominio: loja.dominio || null,
      email_admin: loja.email_admin,
      telefone_admin: loja.telefone_admin || null,
      plano: loja.plano || 'trial',
      ativo: true,
      trial_ate: loja.plano === 'trial' ? new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString() : null,
      limite_produtos: loja.plano === 'premium' ? 999999 : loja.plano === 'professional' ? 1000 : 100,
      limite_pedidos: loja.plano === 'premium' ? 999999 : loja.plano === 'professional' ? 10000 : 500,
    }).select().single();

    if (lojaErr || !novaLoja) {
      return NextResponse.json({ error: `Erro ao criar loja: ${lojaErr?.message}` }, { status: 500 });
    }

    // Usuário admin
    let userId: string;
    const { data: existentes } = await admin.auth.admin.listUsers({ page: 1, perPage: 1000 });
    const jaExiste = existentes?.users?.find(u => u.email?.toLowerCase() === adminInput.email.toLowerCase());

    if (jaExiste) {
      userId = jaExiste.id;
    } else {
      const { data: novoUser, error: userErr } = await admin.auth.admin.createUser({
        email: adminInput.email,
        password: adminInput.senha,
        email_confirm: true,
        user_metadata: { full_name: adminInput.nome },
      });
      if (userErr || !novoUser.user) {
        await admin.from('lojas').delete().eq('id', novaLoja.id);
        return NextResponse.json({ error: `Erro ao criar usuário: ${userErr?.message}` }, { status: 500 });
      }
      userId = novoUser.user.id;
    }

    await admin.from('admins').upsert({
      id: userId, nome: adminInput.nome, nivel: 'admin', loja_id: novaLoja.id,
    }, { onConflict: 'id' });

    // Template
    const seed: { categorias: number; produtos: number; configs: number } = { categorias: 0, produtos: 0, configs: 0 };

    if (incluirTemplate) {
      // Configs
      const configsObj = TEMPLATE_CONFIGS(loja);
      const configRows = Object.entries(configsObj).map(([chave, valor]) => ({
        chave, valor: String(valor), loja_id: novaLoja.id, tipo: 'text', grupo: 'geral',
      }));
      const { error: cfgErr } = await admin.from('configuracoes')
        .upsert(configRows, { onConflict: 'chave,loja_id' });
      if (!cfgErr) seed.configs = configRows.length;

      // Categorias
      const catsToInsert = TEMPLATE_CATEGORIAS.map(c => ({
        ...c, slug: `${c.slug}-${novaLoja.slug}`, ativo: true, loja_id: novaLoja.id,
      }));
      const { data: catsCriadas } = await admin.from('categorias').insert(catsToInsert).select();
      seed.categorias = (catsCriadas ?? []).length;

      const catsBySlug = new Map(
        (catsCriadas ?? []).map((c: { id: string; slug: string }) => [c.slug.replace(`-${novaLoja.slug}`, ''), c.id])
      );

      // Produtos
      for (const p of TEMPLATE_PRODUTOS) {
        const catId = catsBySlug.get(p.categoria_slug);
        const { data: produto } = await admin.from('produtos').insert({
          nome: p.nome, slug: `${p.slug}-${novaLoja.slug}`, descricao: p.descricao,
          preco: p.preco, preco_antigo: p.preco_antigo ?? null,
          badge: p.badge ?? null, destaque: p.destaque, ativo: true,
          peso_gramas: 500, categoria_id: catId, loja_id: novaLoja.id,
        }).select().single();

        if (produto) {
          await admin.from('produto_imagens').insert({
            produto_id: produto.id, url: p.imagem, ordem: 0, principal: true, loja_id: novaLoja.id,
          });
          await admin.from('produto_variantes').insert([
            { produto_id: produto.id, tamanho: 'P', cor: 'Único', estoque: 10, loja_id: novaLoja.id },
            { produto_id: produto.id, tamanho: 'M', cor: 'Único', estoque: 10, loja_id: novaLoja.id },
            { produto_id: produto.id, tamanho: 'G', cor: 'Único', estoque: 10, loja_id: novaLoja.id },
          ]);
          seed.produtos += 1;
        }
      }
    }

    return NextResponse.json({
      ok: true,
      loja: novaLoja,
      admin: { id: userId, email: adminInput.email, nome: adminInput.nome, jaExistia: !!jaExiste },
      seed,
      mensagem: `Loja "${novaLoja.nome}" criada com sucesso!`,
    });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : 'Erro interno' }, { status: 500 });
  }
}
