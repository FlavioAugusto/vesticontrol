import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/admin';

export async function GET(req: NextRequest) {
  try {
    const lojaId = req.nextUrl.searchParams.get('loja_id');
    const supabase = createClient();

    if (lojaId) {
      // Dashboard de UMA loja específica
      const [
        { data: produtos, count: totalProdutos },
        { data: pedidos, count: totalPedidos },
        { data: clientes, count: totalClientes },
        { data: loja },
      ] = await Promise.all([
        supabase.from('produtos').select('id, nome, ativo, preco, created_at', { count: 'exact' }).eq('loja_id', lojaId).order('created_at', { ascending: false }).limit(5),
        supabase.from('pedidos').select('id, numero, total, status, created_at, clientes(nome)', { count: 'exact' }).eq('loja_id', lojaId).order('created_at', { ascending: false }).limit(10),
        supabase.from('clientes').select('id, nome, sobrenome, created_at', { count: 'exact' }).eq('loja_id', lojaId).order('created_at', { ascending: false }).limit(10),
        supabase.from('lojas').select('*').eq('id', lojaId).single(),
      ]);

      // Faturamento real (pedidos pagos)
      const { data: pagos } = await supabase
        .from('pedidos').select('total').eq('loja_id', lojaId)
        .in('status', ['pago', 'enviado', 'entregue']);
      const faturamento = (pagos ?? []).reduce((s: number, p: { total: number }) => s + Number(p.total), 0);

      // Pedidos por status
      const { data: porStatus } = await supabase
        .from('pedidos').select('status').eq('loja_id', lojaId);
      const statusCount: Record<string, number> = {};
      (porStatus ?? []).forEach((p: { status: string }) => { statusCount[p.status] = (statusCount[p.status] || 0) + 1; });

      return NextResponse.json({
        loja,
        stats: {
          totalProdutos: totalProdutos ?? 0,
          totalPedidos: totalPedidos ?? 0,
          totalClientes: totalClientes ?? 0,
          faturamento,
          statusCount,
        },
        recentes: {
          produtos: produtos ?? [],
          pedidos: pedidos ?? [],
          clientes: clientes ?? [],
        },
      });
    }

    // Dashboard GERAL — todas as lojas
    const { data: lojas } = await supabase.from('lojas').select('*').order('created_at', { ascending: false });

    const lojasComStats = await Promise.all(
      (lojas ?? []).map(async (l: { id: string }) => {
        const [
          { count: produtos },
          { count: pedidos },
          { count: clientes },
          { data: pagos },
        ] = await Promise.all([
          supabase.from('produtos').select('*', { count: 'exact', head: true }).eq('loja_id', l.id),
          supabase.from('pedidos').select('*', { count: 'exact', head: true }).eq('loja_id', l.id),
          supabase.from('clientes').select('*', { count: 'exact', head: true }).eq('loja_id', l.id),
          supabase.from('pedidos').select('total').eq('loja_id', l.id).in('status', ['pago', 'enviado', 'entregue']),
        ]);
        const faturamento = (pagos ?? []).reduce((s: number, p: { total: number }) => s + Number(p.total), 0);
        return { ...l, _stats: { produtos: produtos ?? 0, pedidos: pedidos ?? 0, clientes: clientes ?? 0, faturamento } };
      })
    );

    // Totais globais
    const totais = lojasComStats.reduce((acc, l) => ({
      produtos: acc.produtos + (l._stats?.produtos ?? 0),
      pedidos: acc.pedidos + (l._stats?.pedidos ?? 0),
      clientes: acc.clientes + (l._stats?.clientes ?? 0),
      faturamento: acc.faturamento + (l._stats?.faturamento ?? 0),
    }), { produtos: 0, pedidos: 0, clientes: 0, faturamento: 0 });

    return NextResponse.json({ lojas: lojasComStats, totais });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
