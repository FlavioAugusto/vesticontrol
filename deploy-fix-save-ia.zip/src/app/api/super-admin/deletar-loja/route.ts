import { NextRequest, NextResponse } from 'next/server';
import { createClient as createServer } from '@/lib/supabase/server';
import { createClient as createAdmin } from '@/lib/supabase/admin';

/**
 * Deleta uma loja COMPLETAMENTE: produtos, categorias, configs, admins, pedidos, clientes.
 * Não pode deletar a loja default (By Marcelo, id = 00000...0001).
 */
export async function DELETE(req: NextRequest) {
  try {
    const server = createServer();
    const { data: { user } } = await server.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });

    const admin = createAdmin();
    const { data: ehSuper } = await admin.from('super_admins').select('id').eq('id', user.id).maybeSingle();
    if (!ehSuper) return NextResponse.json({ error: 'Acesso negado' }, { status: 403 });

    const { loja_id, confirmacao } = await req.json();
    if (!loja_id) return NextResponse.json({ error: 'loja_id obrigatório' }, { status: 400 });

    // 🛡️ Proteção: não deleta a loja default
    if (loja_id === '00000000-0000-0000-0000-000000000001') {
      return NextResponse.json({
        error: 'A loja principal não pode ser deletada. Use desativar.',
      }, { status: 403 });
    }

    const { data: loja } = await admin.from('lojas').select('nome, slug').eq('id', loja_id).maybeSingle();
    if (!loja) return NextResponse.json({ error: 'Loja não encontrada' }, { status: 404 });

    // 🛡️ Proteção: precisa confirmar com o nome da loja
    if (confirmacao !== loja.nome) {
      return NextResponse.json({
        error: `Confirme digitando exatamente: "${loja.nome}"`,
        code: 'CONFIRMACAO_INVALIDA',
      }, { status: 400 });
    }

    // Conta o que vai ser deletado
    const [{ count: nProdutos }, { count: nPedidos }, { count: nClientes }, { count: nAdmins }] = await Promise.all([
      admin.from('produtos').select('*', { count: 'exact', head: true }).eq('loja_id', loja_id),
      admin.from('pedidos').select('*', { count: 'exact', head: true }).eq('loja_id', loja_id),
      admin.from('clientes').select('*', { count: 'exact', head: true }).eq('loja_id', loja_id),
      admin.from('admins').select('*', { count: 'exact', head: true }).eq('loja_id', loja_id),
    ]);

    // Deleção em cascata (a maioria já tem ON DELETE CASCADE no schema)
    // Mas vamos garantir
    await admin.from('produto_imagens').delete().eq('loja_id', loja_id);
    await admin.from('produto_variantes').delete().eq('loja_id', loja_id);
    await admin.from('pedido_itens').delete().in('pedido_id',
      (await admin.from('pedidos').select('id').eq('loja_id', loja_id)).data?.map((p: { id: string }) => p.id) ?? []
    );
    await admin.from('pedidos').delete().eq('loja_id', loja_id);
    await admin.from('enderecos').delete().eq('loja_id', loja_id);
    await admin.from('lista_desejos').delete().eq('loja_id', loja_id);
    await admin.from('avaliacoes').delete().eq('loja_id', loja_id);
    await admin.from('cupons').delete().eq('loja_id', loja_id);
    await admin.from('clientes').delete().eq('loja_id', loja_id);
    await admin.from('produtos').delete().eq('loja_id', loja_id);
    await admin.from('categorias').delete().eq('loja_id', loja_id);
    await admin.from('configuracoes').delete().eq('loja_id', loja_id);
    await admin.from('admins').delete().eq('loja_id', loja_id);

    // Finalmente, a loja
    const { error } = await admin.from('lojas').delete().eq('id', loja_id);
    if (error) {
      return NextResponse.json({ error: `Erro ao deletar loja: ${error.message}` }, { status: 500 });
    }

    return NextResponse.json({
      ok: true,
      mensagem: `Loja "${loja.nome}" deletada com sucesso!`,
      removidos: {
        produtos: nProdutos ?? 0,
        pedidos: nPedidos ?? 0,
        clientes: nClientes ?? 0,
        admins: nAdmins ?? 0,
      },
    });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : 'Erro' }, { status: 500 });
  }
}
