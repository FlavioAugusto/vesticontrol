import { NextRequest, NextResponse } from 'next/server';
import { createClient as createServer } from '@/lib/supabase/server';
import { createClient as createAdmin } from '@/lib/supabase/admin';

/**
 * Remove TODOS os vestígios de template de uma loja:
 * - Produtos com [EXEMPLO] no nome
 * - Categorias do template (slugs: lancamentos-{loja}, mais-vendidos-{loja}, promocoes-{loja})
 * - Configurações com valores [EXEMPLO] ou de template
 * Preserva produtos/categorias/configs reais.
 */

// Slugs base das categorias do template
const TEMPLATE_CAT_SLUGS = ['lancamentos', 'mais-vendidos', 'promocoes'];

// Chaves de configurações criadas pelo template (que contêm placeholder)
const TEMPLATE_CONFIG_KEYS_COM_PLACEHOLDER = [
  'hero_titulo_1', 'hero_subtitulo_1', 'hero_descricao_1',
];

export async function POST(req: NextRequest) {
  try {
    const server = createServer();
    const { data: { user } } = await server.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });

    const admin = createAdmin();
    const { data: ehSuper } = await admin.from('super_admins').select('id').eq('id', user.id).maybeSingle();
    if (!ehSuper) return NextResponse.json({ error: 'Acesso negado' }, { status: 403 });

    const { loja_id } = await req.json();
    if (!loja_id) return NextResponse.json({ error: 'loja_id obrigatório' }, { status: 400 });

    const { data: loja } = await admin.from('lojas').select('slug').eq('id', loja_id).maybeSingle();
    if (!loja) return NextResponse.json({ error: 'Loja não encontrada' }, { status: 404 });
    const lojaSlug = loja.slug as string;

    const stats = {
      produtos: 0,
      imagens: 0,
      variantes: 0,
      categorias: 0,
      configs: 0,
    };

    // ─── 1. PRODUTOS [EXEMPLO] ou [DEMO] ─────────────────────────────────────
    const { data: produtosExemplo } = await admin
      .from('produtos').select('id').eq('loja_id', loja_id)
      .or('nome.ilike.%[EXEMPLO]%,nome.ilike.%[DEMO]%');
    const produtoIds = (produtosExemplo ?? []).map((p: { id: string }) => p.id);

    if (produtoIds.length > 0) {
      // Imagens e variantes (FK cascade pode fazer isso, mas garantimos)
      const { data: imgs } = await admin.from('produto_imagens').delete()
        .in('produto_id', produtoIds).select('id');
      stats.imagens = (imgs ?? []).length;

      const { data: vars } = await admin.from('produto_variantes').delete()
        .in('produto_id', produtoIds).select('id');
      stats.variantes = (vars ?? []).length;

      const { data: prods } = await admin.from('produtos').delete()
        .in('id', produtoIds).select('id');
      stats.produtos = (prods ?? []).length;
    }

    // ─── 2. CATEGORIAS DO TEMPLATE ───────────────────────────────────────────
    // Template usa padrão: <slug-base>-<loja-slug>
    const templateCatSlugs = TEMPLATE_CAT_SLUGS.map(s => `${s}-${lojaSlug}`);
    const { data: cats } = await admin.from('categorias').delete()
      .eq('loja_id', loja_id).in('slug', templateCatSlugs).select('id');
    stats.categorias = (cats ?? []).length;

    // ─── 3. CONFIGURAÇÕES COM PLACEHOLDER ────────────────────────────────────
    // Remove configs cujo valor contém [EXEMPLO] ou textos de template conhecidos
    const { data: configsTemplate } = await admin.from('configuracoes')
      .select('chave, valor').eq('loja_id', loja_id);

    const chavesParaRemover: string[] = [];
    (configsTemplate ?? []).forEach((c: { chave: string; valor: string | null }) => {
      const v = c.valor || '';
      if (v.includes('[EXEMPLO]')
        || v.includes('[DEMO]')
        || v.includes('[EDITE')
        || v.includes('[PERSONALIZE')
        || (TEMPLATE_CONFIG_KEYS_COM_PLACEHOLDER.includes(c.chave) && (v.includes('Nova Coleção') || v.includes('EDITE')))
      ) {
        chavesParaRemover.push(c.chave);
      }
    });

    if (chavesParaRemover.length > 0) {
      const { data: confs } = await admin.from('configuracoes').delete()
        .eq('loja_id', loja_id).in('chave', chavesParaRemover).select('chave');
      stats.configs = (confs ?? []).length;
    }

    return NextResponse.json({
      ok: true,
      mensagem: `Limpeza concluída! ${stats.produtos} produto(s), ${stats.categorias} categoria(s) e ${stats.configs} config(s) de template removido(s).`,
      stats,
    });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : 'Erro' }, { status: 500 });
  }
}
