import { NextResponse } from 'next/server';
import { createClient as createServer } from '@/lib/supabase/server';
import { createClient as createAdmin } from '@/lib/supabase/admin';

/**
 * Lista TODOS os admins e super_admins do sistema.
 * Acesso: apenas super_admins logados.
 */
export async function GET() {
  try {
    // 1. Autenticação — só super_admin pode ver
    const server = createServer();
    const { data: { user } } = await server.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });

    const admin = createAdmin();
    const { data: ehSuper } = await admin
      .from('super_admins').select('id').eq('id', user.id).maybeSingle();
    if (!ehSuper) return NextResponse.json({ error: 'Acesso negado' }, { status: 403 });

    // 2. Busca todos os usuários do auth (uma única vez)
    const { data: usersData } = await admin.auth.admin.listUsers();
    const users = usersData?.users ?? [];
    const userById = new Map(users.map(u => [u.id, u]));

    // 3. Super Admins
    const { data: superAdmins } = await admin
      .from('super_admins').select('id, created_at').order('created_at');

    const superAdminsLista = (superAdmins ?? []).map((sa: { id: string; created_at: string }) => {
      const u = userById.get(sa.id);
      return {
        id: sa.id,
        email: u?.email ?? '(usuário removido)',
        nome: u?.user_metadata?.full_name ?? u?.user_metadata?.name ?? '—',
        criado_em: sa.created_at,
        ultimo_login: u?.last_sign_in_at ?? null,
        confirmado: !!u?.email_confirmed_at,
      };
    });

    // 4. Admins de loja — busca separada pra não depender de FK
    const { data: admins } = await admin
      .from('admins').select('id, nome, nivel, loja_id, created_at').order('created_at');

    const { data: lojas } = await admin.from('lojas').select('id, nome, slug');
    const lojaById = new Map((lojas ?? []).map((l: { id: string; nome: string; slug: string }) => [l.id, l]));

    const adminsLista = (admins ?? []).map((a: {
      id: string; nome: string; nivel: string; loja_id: string; created_at: string;
    }) => {
      const u = userById.get(a.id);
      const loja = lojaById.get(a.loja_id);
      return {
        id: a.id,
        email: u?.email ?? '(usuário removido)',
        nome: a.nome,
        nivel: a.nivel,
        loja_id: a.loja_id,
        loja_nome: loja?.nome ?? '(loja não encontrada)',
        loja_slug: loja?.slug ?? null,
        criado_em: a.created_at,
        ultimo_login: u?.last_sign_in_at ?? null,
        confirmado: !!u?.email_confirmed_at,
      };
    });

    return NextResponse.json({
      super_admins: superAdminsLista,
      admins: adminsLista,
      total_super_admins: superAdminsLista.length,
      total_admins: adminsLista.length,
    });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : 'Erro' }, { status: 500 });
  }
}
