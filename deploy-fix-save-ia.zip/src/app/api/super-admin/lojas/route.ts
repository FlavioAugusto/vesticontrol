import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/admin';
import { createClient as createServer } from '@/lib/supabase/server';

/**
 * Verifica se usuário está logado (middleware já garante que é super_admin).
 */
async function isLoggedIn(): Promise<boolean> {
  try {
    const supabase = createServer();
    const { data: { user } } = await supabase.auth.getUser();
    return !!user;
  } catch {
    return false;
  }
}

export async function GET() {
  if (!(await isLoggedIn())) {
    return NextResponse.json({ error: 'Não autenticado', code: 'UNAUTHENTICATED' }, { status: 401 });
  }
  try {
    const supabase = createClient();
    const { data: lojas } = await supabase
      .from('lojas')
      .select('*')
      .order('created_at', { ascending: false });

    // Adiciona estatísticas básicas por loja
    const lojasComStats = await Promise.all(
      (lojas ?? []).map(async (l: { id: string }) => {
        const [{ count: produtos }, { count: pedidos }, { count: clientes }] = await Promise.all([
          supabase.from('produtos').select('*', { count: 'exact', head: true }).eq('loja_id', l.id),
          supabase.from('pedidos').select('*', { count: 'exact', head: true }).eq('loja_id', l.id),
          supabase.from('clientes').select('*', { count: 'exact', head: true }).eq('loja_id', l.id),
        ]);
        return { ...l, _stats: { produtos: produtos ?? 0, pedidos: pedidos ?? 0, clientes: clientes ?? 0 } };
      })
    );
    return NextResponse.json(lojasComStats);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  if (!(await isLoggedIn())) {
    return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });
  }
  try {
    const { nome, slug, email_admin, telefone_admin, plano, dominio } = await req.json();
    if (!nome || !slug || !email_admin) {
      return NextResponse.json({ error: 'Nome, slug e email são obrigatórios' }, { status: 400 });
    }

    const slugLimpo = slug.toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');

    const supabase = createClient();

    // Verifica se já existe slug
    const { data: existente } = await supabase
      .from('lojas').select('id').eq('slug', slugLimpo).maybeSingle();
    if (existente) {
      return NextResponse.json({ error: 'Já existe uma loja com esse slug' }, { status: 409 });
    }

    // Limites por plano
    const limites = {
      trial:        { limite_produtos: 30,  limite_pedidos: 50 },
      starter:      { limite_produtos: 50,  limite_pedidos: 100 },
      professional: { limite_produtos: 500, limite_pedidos: 1000 },
      premium:      { limite_produtos: 99999, limite_pedidos: 99999 },
    };
    const limite = limites[plano as keyof typeof limites] ?? limites.starter;

    // Trial de 7 dias por padrão
    const trialAte = plano === 'trial' ? new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() : null;

    const { data, error } = await supabase.from('lojas').insert({
      nome, slug: slugLimpo, email_admin, telefone_admin: telefone_admin ?? null,
      dominio: dominio ?? null, plano: plano ?? 'starter', ativo: true,
      trial_ate: trialAte,
      ...limite,
    }).select().single();

    if (error) throw error;
    return NextResponse.json({ ok: true, loja: data });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  if (!(await isLoggedIn())) {
    return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });
  }
  try {
    const body = await req.json();
    const { id, ...patch } = body;
    if (!id) return NextResponse.json({ error: 'id obrigatório' }, { status: 400 });

    const supabase = createClient();

    // Validação especial para domínio
    if ('dominio' in patch) {
      const dom = (patch.dominio || '').trim().toLowerCase()
        .replace(/^https?:\/\//, '')
        .replace(/\/$/, '')
        .replace(/^www\./, ''); // armazena sem www

      if (dom) {
        // Valida formato básico
        const regex = /^([a-z0-9]([a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/;
        if (!regex.test(dom)) {
          return NextResponse.json({
            error: `Domínio inválido: "${dom}". Use formato: lojadocliente.com.br`,
          }, { status: 400 });
        }

        // Verifica unicidade
        const { data: usado } = await supabase
          .from('lojas').select('id, nome').eq('dominio', dom).neq('id', id).maybeSingle();
        if (usado) {
          return NextResponse.json({
            error: `O domínio "${dom}" já está em uso pela loja "${usado.nome}"`,
          }, { status: 409 });
        }

        patch.dominio = dom;
      } else {
        patch.dominio = null;
      }
    }

    // Validação de slug se alterado
    if ('slug' in patch) {
      const slug = (patch.slug || '').toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
      const { data: usado } = await supabase
        .from('lojas').select('id, nome').eq('slug', slug).neq('id', id).maybeSingle();
      if (usado) {
        return NextResponse.json({
          error: `O slug "${slug}" já está em uso pela loja "${usado.nome}"`,
        }, { status: 409 });
      }
      patch.slug = slug;
    }

    patch.updated_at = new Date().toISOString();

    const { data, error } = await supabase.from('lojas').update(patch).eq('id', id).select().single();
    if (error) throw error;

    return NextResponse.json({ ok: true, loja: data });
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'Erro';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
