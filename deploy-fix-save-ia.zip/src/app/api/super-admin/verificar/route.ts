import { NextResponse } from 'next/server';
import { createClient as createServer } from '@/lib/supabase/server';
import { createClient as createAdmin } from '@/lib/supabase/admin';

/**
 * Verifica se o usuário logado é super_admin.
 * Usa service role pra bypassar RLS.
 */
export async function GET() {
  try {
    const server = createServer();
    const { data: { user } } = await server.auth.getUser();
    if (!user) {
      return NextResponse.json({ eh_super_admin: false, motivo: 'nao_logado' }, { status: 401 });
    }

    const admin = createAdmin();
    const { data, error } = await admin
      .from('super_admins')
      .select('id, nome')
      .eq('id', user.id)
      .maybeSingle();

    if (error) {
      return NextResponse.json({ eh_super_admin: false, erro: error.message }, { status: 500 });
    }

    return NextResponse.json({
      eh_super_admin: !!data,
      user_id: user.id,
      email: user.email,
      nome: data?.nome ?? null,
    });
  } catch (e) {
    return NextResponse.json({
      eh_super_admin: false,
      erro: e instanceof Error ? e.message : 'Erro',
    }, { status: 500 });
  }
}
