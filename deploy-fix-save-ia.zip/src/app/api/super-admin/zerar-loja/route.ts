import { NextRequest, NextResponse } from 'next/server';
import { createClient as createServer } from '@/lib/supabase/server';
import { createClient as createAdmin } from '@/lib/supabase/admin';

/**
 * Zera uma loja: remove TODOS os produtos, categorias e configurações.
 * Preserva: a loja em si, seus admins, pedidos antigos, clientes.
 * Útil pra "limpar" uma loja antes de aplicar template novo ou começar do zero.
 */
export async function POST(req: NextRequest) {
  try {
    const server = createServer();
    const { data: { user } } = await server.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });

    const admin = createAdmin();
    const { data: ehSuper } = await admin.from('super_admins').select('id').eq('id', user.id).maybeSingle();
    if (!ehSuper) return NextResponse.json({ error: 'Acesso negado' }, { status: 403 });

    const { loja_id, confirmacao, manter_configs_basicas } = await req.json();
    if (!loja_id) return NextResponse.json({ error: 'loja_id obrigatório' }, { status: 400 });

    const { data: loja } = await admin.from('lojas').select('nome, slug').eq('id', loja_id).maybeSingle();
    if (!loja) return NextResponse.json({ error: 'Loja não encontrada' }, { status: 404 });

    if (confirmacao !== 'ZERAR') {
      return NextResponse.json({
        error: 'Confirme digitando "ZERAR" exatamente',
        code: 'CONFIRMACAO_INVALIDA',
      }, { status: 400 });
    }

    // 🛡️ Zerar NÃO MEXE em admins, pedidos, clientes — só conteúdo de loja

    const stats = { produtos: 0, categorias: 0, configs: 0, imagens: 0, variantes: 0 };

    // 1. Imagens e variantes (CASCADE deveria limpar, mas garantimos)
    const { data: prods } = await admin.from('produtos').select('id').eq('loja_id', loja_id);
    const prodIds = (prods ?? []).map((p: { id: string }) => p.id);
    if (prodIds.length > 0) {
      const { data: imgs } = await admin.from('produto_imagens').delete()
        .in('produto_id', prodIds).select('id');
      stats.imagens = (imgs ?? []).length;
      const { data: vars } = await admin.from('produto_variantes').delete()
        .in('produto_id', prodIds).select('id');
      stats.variantes = (vars ?? []).length;
    }

    // 2. Produtos
    const { data: prodDel } = await admin.from('produtos').delete()
      .eq('loja_id', loja_id).select('id');
    stats.produtos = (prodDel ?? []).length;

    // 3. Categorias
    const { data: catDel } = await admin.from('categorias').delete()
      .eq('loja_id', loja_id).select('id');
    stats.categorias = (catDel ?? []).length;

    // 4. Configurações (opcionalmente preserva as básicas como nome da loja)
    let configsQuery = admin.from('configuracoes').delete().eq('loja_id', loja_id);
    if (manter_configs_basicas) {
      configsQuery = configsQuery.not('chave', 'in', '(loja_nome,loja_email,loja_telefone,loja_whatsapp)');
    }
    const { data: cfgDel } = await configsQuery.select('chave');
    stats.configs = (cfgDel ?? []).length;

    return NextResponse.json({
      ok: true,
      mensagem: `Loja "${loja.nome}" zerada! ${stats.produtos} produto(s), ${stats.categorias} categoria(s), ${stats.configs} config(s) removidos.`,
      stats,
    });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : 'Erro' }, { status: 500 });
  }
}
