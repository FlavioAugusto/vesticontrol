'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Shield, User, Store, ArrowLeft, CheckCircle, XCircle, Clock, RefreshCw } from 'lucide-react';

interface SuperAdmin {
  id: string;
  email: string;
  nome: string;
  criado_em: string;
  ultimo_login: string | null;
  confirmado: boolean;
}

interface Admin extends SuperAdmin {
  nivel: string;
  loja_id: string;
  loja_nome: string;
  loja_slug: string | null;
}

interface Resposta {
  super_admins: SuperAdmin[];
  admins: Admin[];
  total_super_admins: number;
  total_admins: number;
}

function formatData(s: string | null) {
  if (!s) return 'Nunca';
  try {
    return new Date(s).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
  } catch { return '—'; }
}

export default function ListaAdminsPage() {
  const router = useRouter();
  const [dados, setDados] = useState<Resposta | null>(null);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState('');

  async function carregar() {
    setLoading(true);
    setErro('');
    try {
      const res = await fetch('/api/super-admin/listar-admins', { cache: 'no-store' });
      const data = await res.json();
      if (!res.ok) { setErro(data.error ?? 'Erro ao carregar'); return; }
      setDados(data);
    } catch {
      setErro('Erro de conexão');
    } finally { setLoading(false); }
  }

  useEffect(() => { carregar(); }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 p-4 sm:p-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <button onClick={() => router.push('/super-admin')}
              className="bg-white/10 hover:bg-white/20 text-white p-2 rounded-lg transition-all">
              <ArrowLeft size={18} />
            </button>
            <div>
              <h1 className="text-white font-serif text-2xl">Administradores do Sistema</h1>
              <p className="text-purple-200/70 text-sm">Quem tem acesso ao painel</p>
            </div>
          </div>
          <button onClick={carregar}
            className="bg-white/10 hover:bg-white/20 text-white px-3 py-2 rounded-lg text-xs flex items-center gap-1.5 transition-all">
            <RefreshCw size={12} className={loading ? 'animate-spin' : ''} /> Atualizar
          </button>
        </div>

        {loading && (
          <div className="bg-white/5 backdrop-blur rounded-2xl p-12 text-center">
            <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto" />
          </div>
        )}

        {erro && (
          <div className="bg-red-500/20 border border-red-400/40 text-red-100 rounded-xl p-4 mb-4 text-sm">
            ❌ {erro}
          </div>
        )}

        {dados && !loading && (
          <>
            {/* Totais */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-white/10 backdrop-blur rounded-2xl p-5">
                <div className="flex items-center gap-2 text-purple-200 text-xs uppercase tracking-wider mb-1">
                  <Shield size={14} /> Super Admins
                </div>
                <p className="text-white text-3xl font-bold">{dados.total_super_admins}</p>
              </div>
              <div className="bg-white/10 backdrop-blur rounded-2xl p-5">
                <div className="flex items-center gap-2 text-purple-200 text-xs uppercase tracking-wider mb-1">
                  <User size={14} /> Admins de Loja
                </div>
                <p className="text-white text-3xl font-bold">{dados.total_admins}</p>
              </div>
            </div>

            {/* Super Admins */}
            <div className="bg-white rounded-2xl p-5 sm:p-6 mb-5 shadow-2xl">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-9 h-9 bg-gradient-to-br from-amber-500 to-amber-600 rounded-lg flex items-center justify-center">
                  <Shield size={16} className="text-white" />
                </div>
                <div>
                  <h2 className="font-serif text-lg text-charcoal">Super Admins</h2>
                  <p className="text-xs text-gray-500">Acesso total ao sistema (todas as lojas)</p>
                </div>
              </div>

              {dados.super_admins.length === 0 ? (
                <p className="text-gray-400 text-sm italic py-4">Nenhum super admin cadastrado.</p>
              ) : (
                <div className="space-y-2">
                  {dados.super_admins.map(sa => (
                    <div key={sa.id} className="border border-gray-100 rounded-xl p-3 hover:bg-amber-50/30 transition-all">
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-charcoal text-sm break-all">{sa.email}</p>
                          {sa.nome !== '—' && <p className="text-xs text-gray-500">{sa.nome}</p>}
                        </div>
                        <div className="flex items-center gap-2">
                          {sa.confirmado
                            ? <span className="flex items-center gap-1 text-[10px] bg-emerald-100 text-emerald-700 px-2 py-1 rounded-md font-semibold"><CheckCircle size={10} /> Confirmado</span>
                            : <span className="flex items-center gap-1 text-[10px] bg-amber-100 text-amber-700 px-2 py-1 rounded-md font-semibold"><XCircle size={10} /> Não confirmado</span>}
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-4 mt-2 text-[11px] text-gray-400">
                        <span className="flex items-center gap-1"><Clock size={10} /> Último login: {formatData(sa.ultimo_login)}</span>
                        <span>Criado: {formatData(sa.criado_em)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Admins de Loja */}
            <div className="bg-white rounded-2xl p-5 sm:p-6 shadow-2xl">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-9 h-9 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <Store size={16} className="text-white" />
                </div>
                <div>
                  <h2 className="font-serif text-lg text-charcoal">Admins de Loja</h2>
                  <p className="text-xs text-gray-500">Acesso restrito à sua loja</p>
                </div>
              </div>

              {dados.admins.length === 0 ? (
                <p className="text-gray-400 text-sm italic py-4">Nenhum admin de loja cadastrado.</p>
              ) : (
                <div className="space-y-2">
                  {dados.admins.map(a => (
                    <div key={a.id} className="border border-gray-100 rounded-xl p-3 hover:bg-purple-50/30 transition-all">
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-charcoal text-sm break-all">{a.email}</p>
                          <div className="flex flex-wrap items-center gap-2 mt-0.5">
                            {a.nome && <span className="text-xs text-gray-500">{a.nome}</span>}
                            <span className="text-[10px] bg-purple-100 text-purple-700 px-2 py-0.5 rounded-md font-semibold uppercase tracking-wider">
                              {a.nivel}
                            </span>
                            <span className="text-[10px] bg-gray-100 text-gray-700 px-2 py-0.5 rounded-md font-medium">
                              🏪 {a.loja_nome}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {a.confirmado
                            ? <span className="flex items-center gap-1 text-[10px] bg-emerald-100 text-emerald-700 px-2 py-1 rounded-md font-semibold"><CheckCircle size={10} /> Confirmado</span>
                            : <span className="flex items-center gap-1 text-[10px] bg-amber-100 text-amber-700 px-2 py-1 rounded-md font-semibold"><XCircle size={10} /> Não confirmado</span>}
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-4 mt-2 text-[11px] text-gray-400">
                        <span className="flex items-center gap-1"><Clock size={10} /> Último login: {formatData(a.ultimo_login)}</span>
                        <span>Criado: {formatData(a.criado_em)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
