'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { Store, Lock, Mail, ArrowLeft, CheckCircle } from 'lucide-react';

type Etapa = 'login' | 'esqueci' | 'enviado';

export default function SuperAdminLoginPage() {
  const router = useRouter();
  const [etapa, setEtapa] = useState<Etapa>('login');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [loading, setLoading] = useState(false);
  const [erro, setErro] = useState('');

  async function entrar(e: React.FormEvent) {
    e.preventDefault();
    setErro('');
    setLoading(true);
    try {
      const supabase = createClient();
      const { error } = await supabase.auth.signInWithPassword({ email, password: senha });
      if (error) { setErro('Email ou senha inválidos'); return; }

      // Verifica via API (service role bypassa RLS)
      const res = await fetch('/api/super-admin/verificar', { cache: 'no-store' });
      const data = await res.json();
      if (!data.eh_super_admin) {
        await supabase.auth.signOut();
        setErro(data.erro ?? 'Acesso negado. Você não é super-admin.');
        return;
      }
      router.push('/super-admin');
      router.refresh();
    } catch { setErro('Erro ao fazer login'); }
    finally { setLoading(false); }
  }

  async function enviarRecuperacao(e: React.FormEvent) {
    e.preventDefault();
    setErro('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, tipo: 'super_admin' }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (data.code === 'USER_NOT_FOUND') {
          setErro('Este e-mail não está cadastrado em nosso sistema.');
        } else if (data.code === 'NOT_SUPER_ADMIN') {
          setErro('Este e-mail não tem acesso de Super Admin.');
        } else {
          setErro(data.error ?? 'Erro ao enviar email');
        }
        return;
      }
      setEtapa('enviado');
    } catch {
      setErro('Erro de conexão. Tente novamente.');
    } finally {
      setLoading(false);
    }
  }

  // ─── Tela: Email enviado ───
  if (etapa === 'enviado') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-8 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-500/30">
            <CheckCircle size={28} className="text-white" />
          </div>
          <h1 className="font-serif text-2xl text-charcoal mb-2">Email enviado!</h1>
          <p className="text-gray-500 text-sm mb-2">
            Se este email estiver cadastrado, você receberá um link para redefinir sua senha.
          </p>
          <p className="text-gray-400 text-xs mb-6">
            Verifique sua caixa de entrada (e o spam). O link expira em 1 hora.
          </p>
          <button
            onClick={() => { setEtapa('login'); setEmail(''); setSenha(''); setErro(''); }}
            className="w-full border border-gray-200 text-charcoal py-3 rounded-xl text-sm font-semibold hover:bg-gray-50 transition-all flex items-center justify-center gap-2"
          >
            <ArrowLeft size={14} /> Voltar ao login
          </button>
        </div>
      </div>
    );
  }

  // ─── Tela: Esqueci minha senha ───
  if (etapa === 'esqueci') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-8">
          <div className="text-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-600 to-purple-700 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/30">
              <Mail size={28} className="text-white" />
            </div>
            <h1 className="font-serif text-2xl text-charcoal">Recuperar senha</h1>
            <p className="text-gray-400 text-sm mt-1">Enviaremos um link para seu email</p>
          </div>

          <form onSubmit={enviarRecuperacao} className="space-y-4">
            <div>
              <label className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider block mb-1.5">Email cadastrado</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="seu@email.com"
                required
                autoFocus
                className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-100 transition-all"
              />
            </div>

            {erro && (
              <div className="bg-red-50 border border-red-200 text-red-700 text-xs px-3 py-2.5 rounded-lg">
                {erro}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-purple-600 to-purple-700 text-white py-3 rounded-xl text-sm font-semibold hover:from-purple-700 hover:to-purple-800 transition-all shadow-md shadow-purple-500/20 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading
                ? <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Enviando...</>
                : <><Mail size={14} /> Enviar link de recuperação</>
              }
            </button>

            <button
              type="button"
              onClick={() => { setEtapa('login'); setErro(''); }}
              className="w-full text-gray-500 text-xs hover:text-charcoal transition-colors flex items-center justify-center gap-1.5 pt-2"
            >
              <ArrowLeft size={12} /> Voltar ao login
            </button>
          </form>
        </div>
      </div>
    );
  }

  // ─── Tela: Login (padrão) ───
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-600 to-purple-700 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/30">
            <Store size={28} className="text-white" />
          </div>
          <h1 className="font-serif text-2xl text-charcoal">Painel Master</h1>
          <p className="text-gray-400 text-sm mt-1">Acesso exclusivo — Super Admin</p>
        </div>

        <form onSubmit={entrar} className="space-y-4">
          <div>
            <label className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider block mb-1.5">Email</label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="seu@email.com"
              required
              className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-100 transition-all"
            />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider">Senha</label>
              <button
                type="button"
                onClick={() => { setEtapa('esqueci'); setErro(''); setSenha(''); }}
                className="text-[11px] text-purple-600 hover:text-purple-800 font-semibold transition-colors"
              >
                Esqueci minha senha
              </button>
            </div>
            <input
              type="password"
              value={senha}
              onChange={e => setSenha(e.target.value)}
              placeholder="••••••••"
              required
              className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-100 transition-all"
            />
          </div>

          {erro && (
            <div className="bg-red-50 border border-red-200 text-red-700 text-xs px-3 py-2.5 rounded-lg">
              {erro}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-purple-600 to-purple-700 text-white py-3 rounded-xl text-sm font-semibold hover:from-purple-700 hover:to-purple-800 transition-all shadow-md shadow-purple-500/20 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? (
              <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Entrando...</>
            ) : (
              <><Lock size={14} /> Entrar no Painel Master</>
            )}
          </button>
        </form>

        <p className="text-[10px] text-gray-400 text-center mt-6">
          Acesso restrito a super-administradores
        </p>
      </div>
    </div>
  );
}
