'use client';

import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Plus, Store, Users, Package, ShoppingCart, ExternalLink, Power, AlertTriangle, UserPlus, Trash2, X, Eye, EyeOff, Shield, Mail, Phone, Globe, Calendar, DollarSign, Hash, CreditCard, MapPin } from 'lucide-react';
import Link from 'next/link';

interface Loja {
  id: string;
  nome: string;
  slug: string;
  dominio: string | null;
  email_admin: string;
  telefone_admin: string | null;
  plano: 'trial' | 'starter' | 'professional' | 'premium';
  ativo: boolean;
  trial_ate: string | null;
  expira_em: string | null;
  limite_produtos: number;
  limite_pedidos: number;
  created_at: string;
  _stats?: { produtos: number; pedidos: number; clientes: number };
}

interface AdminLoja {
  id: string;
  nome: string;
  email: string;
  nivel: string;
  created_at: string;
}

const PLANO_INFO: Record<Loja['plano'], { label: string; cor: string }> = {
  trial:        { label: '🧪 Trial', cor: 'bg-amber-100 text-amber-700 border-amber-200' },
  starter:      { label: '🟢 Starter', cor: 'bg-green-100 text-green-700 border-green-200' },
  professional: { label: '🔵 Pro', cor: 'bg-blue-100 text-blue-700 border-blue-200' },
  premium:      { label: '🟣 Premium', cor: 'bg-purple-100 text-purple-700 border-purple-200' },
};

export default function SuperAdminPage() {
  const [lojas, setLojas] = useState<Loja[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalNova, setModalNova] = useState(false);
  const [modalAdmin, setModalAdmin] = useState<Loja | null>(null);
  const [modalDetalhes, setModalDetalhes] = useState<Loja | null>(null);
  const [adminsLoja, setAdminsLoja] = useState<AdminLoja[]>([]);
  const [loadingAdmins, setLoadingAdmins] = useState(false);
  const [salvando, setSalvando] = useState(false);
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [aplicandoTemplate, setAplicandoTemplate] = useState(false);

  const [novaLoja, setNovaLoja] = useState({
    nome: '', slug: '', email_admin: '', telefone_admin: '', plano: 'trial' as Loja['plano'], dominio: '',
  });
  const [novaLojaAdmin, setNovaLojaAdmin] = useState({ nome: '', email: '', senha: '' });
  const [incluirTemplate, setIncluirTemplate] = useState(true);

  const [novoAdmin, setNovoAdmin] = useState({ nome: '', email: '', senha: '' });

  useEffect(() => { carregar(); }, []);

  async function carregar() {
    setLoading(true);
    try {
      const res = await fetch('/api/super-admin/lojas');
      if (res.status === 401) { window.location.href = '/super-admin/login'; return; }
      const data = await res.json();
      setLojas(data);
    } catch { toast.error('Erro ao carregar'); }
    finally { setLoading(false); }
  }

  async function abrirAdmins(loja: Loja) {
    setModalAdmin(loja);
    setLoadingAdmins(true);
    setAdminsLoja([]);
    try {
      const res = await fetch(`/api/super-admin/criar-admin?loja_id=${loja.id}`);
      const data = await res.json();
      setAdminsLoja(Array.isArray(data) ? data : []);
    } catch { toast.error('Erro ao carregar admins'); }
    finally { setLoadingAdmins(false); }
  }

  async function criarAdmin() {
    if (!novoAdmin.nome || !novoAdmin.email || !novoAdmin.senha) {
      toast.error('Preencha nome, email e senha'); return;
    }
    if (!modalAdmin) return;
    setSalvando(true);
    try {
      const res = await fetch('/api/super-admin/criar-admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...novoAdmin, loja_id: modalAdmin.id }),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error || 'Erro'); return; }
      toast.success(data.mensagem);
      setAdminsLoja(prev => [...prev, { id: data.usuario.id, nome: data.usuario.nome, email: data.usuario.email, nivel: 'admin', created_at: new Date().toISOString() }]);
      setNovoAdmin({ nome: '', email: '', senha: '' });
    } catch { toast.error('Erro ao criar admin'); }
    finally { setSalvando(false); }
  }

  async function removerAdmin(adminId: string) {
    if (!modalAdmin) return;
    try {
      const res = await fetch('/api/super-admin/criar-admin', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ admin_id: adminId, loja_id: modalAdmin.id }),
      });
      if (!res.ok) { const d = await res.json(); toast.error(d.error || 'Erro'); return; }
      setAdminsLoja(prev => prev.filter(a => a.id !== adminId));
      toast.success('Admin removido');
    } catch { toast.error('Erro ao remover'); }
  }

  async function criarLoja() {
    if (!novaLoja.nome || !novaLoja.slug || !novaLoja.email_admin) {
      toast.error('Preencha nome, slug e email da loja'); return;
    }
    if (!novaLojaAdmin.nome || !novaLojaAdmin.email || !novaLojaAdmin.senha) {
      toast.error('Preencha nome, e-mail e senha do admin'); return;
    }
    if (novaLojaAdmin.senha.length < 6) {
      toast.error('A senha do admin precisa ter no mínimo 6 caracteres'); return;
    }
    setSalvando(true);
    const loadingToast = toast.loading('Criando loja, admin e dados de exemplo...');
    try {
      const res = await fetch('/api/super-admin/criar-loja-completa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          loja: novaLoja,
          admin: novaLojaAdmin,
          incluirTemplate,
        }),
      });
      const data = await res.json();
      toast.dismiss(loadingToast);
      if (!res.ok) { toast.error(data.error || 'Erro'); return; }

      toast.success(
        incluirTemplate
          ? `Loja criada! ${data.seed.categorias} categorias e ${data.seed.produtos} produtos de exemplo adicionados.`
          : 'Loja criada com sucesso!',
        { duration: 6000 }
      );
      setLojas(prev => [data.loja, ...prev]);
      setModalNova(false);
      setNovaLoja({ nome: '', slug: '', email_admin: '', telefone_admin: '', plano: 'trial', dominio: '' });
      setNovaLojaAdmin({ nome: '', email: '', senha: '' });
      setIncluirTemplate(true);
    } catch {
      toast.dismiss(loadingToast);
      toast.error('Erro ao criar');
    }
    finally { setSalvando(false); }
  }

  async function aplicarTemplate(loja: Loja, forcar = false) {
    const msgConfirm = forcar
      ? `⚠️ ATENÇÃO: A loja "${loja.nome}" já tem produtos reais cadastrados.\n\nAplicar o template vai adicionar produtos [EXEMPLO] junto aos produtos reais. Isso pode confundir o admin da loja.\n\nTem CERTEZA que quer aplicar mesmo assim?`
      : `Aplicar template (3 categorias + 3 produtos + configs) na loja "${loja.nome}"?\n\nSó adiciona o que ainda não existe. Não duplica dados.`;
    if (!confirm(msgConfirm)) return;
    setAplicandoTemplate(true);
    const loadingToast = toast.loading('Aplicando template...');
    try {
      const res = await fetch('/api/super-admin/aplicar-template', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ loja_id: loja.id, forcar }),
      });
      const data = await res.json();
      toast.dismiss(loadingToast);

      // Loja em produção — pergunta se quer forçar
      if (res.status === 403 && data.code === 'LOJA_EM_PRODUCAO') {
        if (confirm(`🛡️ Proteção ativada!\n\n${data.error}\n\nDeseja FORÇAR mesmo assim?`)) {
          setAplicandoTemplate(false);
          return aplicarTemplate(loja, true);
        }
        return;
      }

      if (!res.ok) { toast.error(data.error || 'Erro'); return; }
      toast.success(data.mensagem, { duration: 6000 });
      // Atualiza stats
      setLojas(prev => prev.map(l => l.id === loja.id ? {
        ...l,
        _stats: l._stats ? {
          ...l._stats,
          produtos: (l._stats.produtos || 0) + (data.resultado?.produtos || 0),
        } : l._stats,
      } : l));
    } catch {
      toast.dismiss(loadingToast);
      toast.error('Erro de conexão');
    } finally {
      setAplicandoTemplate(false);
    }
  }

  async function limparTemplate(loja: Loja) {
    if (!confirm(`🧹 Remover TODOS os produtos [EXEMPLO] da loja "${loja.nome}"?\n\nEssa ação é irreversível.\nProdutos reais (sem [EXEMPLO] no nome) NÃO serão afetados.`)) return;
    const loadingToast = toast.loading('Limpando template...');
    try {
      const res = await fetch('/api/super-admin/limpar-template', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ loja_id: loja.id }),
      });
      const data = await res.json();
      toast.dismiss(loadingToast);
      if (!res.ok) { toast.error(data.error || 'Erro'); return; }
      toast.success(data.mensagem, { duration: 5000 });
      setLojas(prev => prev.map(l => l.id === loja.id ? {
        ...l,
        _stats: l._stats ? {
          ...l._stats,
          produtos: Math.max(0, (l._stats.produtos || 0) - (data.removidos?.produtos || 0)),
        } : l._stats,
      } : l));
    } catch {
      toast.dismiss(loadingToast);
      toast.error('Erro de conexão');
    }
  }

  async function zerarLoja(loja: Loja) {
    const confirmacao = prompt(`♻️ ZERAR a loja "${loja.nome}"?\n\nEsta ação vai REMOVER:\n• Todos os produtos\n• Todas as categorias\n• Todas as configurações\n\n✅ Preserva: pedidos antigos, admins, clientes.\n\nDigite ZERAR para confirmar:`);
    if (confirmacao !== 'ZERAR') return;
    const loadingToast = toast.loading('Zerando loja...');
    try {
      const res = await fetch('/api/super-admin/zerar-loja', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ loja_id: loja.id, confirmacao: 'ZERAR' }),
      });
      const data = await res.json();
      toast.dismiss(loadingToast);
      if (!res.ok) { toast.error(data.error || 'Erro'); return; }
      toast.success(data.mensagem, { duration: 6000 });
      setLojas(prev => prev.map(l => l.id === loja.id ? {
        ...l,
        _stats: { produtos: 0, pedidos: l._stats?.pedidos ?? 0, clientes: l._stats?.clientes ?? 0 },
      } : l));
    } catch {
      toast.dismiss(loadingToast);
      toast.error('Erro de conexão');
    }
  }

  async function deletarLoja(loja: Loja) {
    const confirmacao = prompt(`🗑️ EXCLUIR a loja "${loja.nome}" PERMANENTEMENTE?\n\n⚠️ ATENÇÃO: Esta ação NÃO pode ser desfeita!\nVai remover TUDO: produtos, pedidos, clientes, admins, configurações.\n\nPara confirmar, digite o nome EXATO da loja:`);
    if (!confirmacao || confirmacao !== loja.nome) {
      if (confirmacao) toast.error('Nome não confere — cancelado');
      return;
    }
    if (!confirm(`Última confirmação: APAGAR "${loja.nome}"?\n\nIsso é IRREVERSÍVEL.`)) return;
    const loadingToast = toast.loading('Excluindo loja...');
    try {
      const res = await fetch('/api/super-admin/deletar-loja', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ loja_id: loja.id, confirmacao }),
      });
      const data = await res.json();
      toast.dismiss(loadingToast);
      if (!res.ok) { toast.error(data.error || 'Erro'); return; }
      toast.success(data.mensagem, { duration: 6000 });
      setLojas(prev => prev.filter(l => l.id !== loja.id));
      setModalDetalhes(null);
    } catch {
      toast.dismiss(loadingToast);
      toast.error('Erro de conexão');
    }
  }

  async function salvarDominio(loja: Loja, novoDominio: string) {
    setSalvando(true);
    try {
      const res = await fetch('/api/super-admin/lojas', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: loja.id, dominio: novoDominio || null }),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error || 'Erro ao salvar domínio'); return false; }
      setLojas(prev => prev.map(l => l.id === loja.id ? { ...l, dominio: data.loja.dominio } : l));
      if (modalDetalhes?.id === loja.id) {
        setModalDetalhes({ ...modalDetalhes, dominio: data.loja.dominio });
      }
      toast.success(novoDominio ? `Domínio "${data.loja.dominio}" salvo!` : 'Domínio removido');
      return true;
    } catch {
      toast.error('Erro de conexão');
      return false;
    } finally {
      setSalvando(false);
    }
  }

  async function toggleAtivo(loja: Loja) {
    try {
      const res = await fetch('/api/super-admin/lojas', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: loja.id, ativo: !loja.ativo }),
      });
      if (!res.ok) { const d = await res.json(); toast.error(d.error || 'Erro'); return; }
      setLojas(prev => prev.map(l => l.id === loja.id ? { ...l, ativo: !loja.ativo } : l));
      toast.success(loja.ativo ? 'Loja desativada' : 'Loja ativada');
    } catch { toast.error('Erro'); }
  }

  function gerarSlug(nome: string) {
    return nome.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  }

  const totalLojas = lojas.length;
  const lojasAtivas = lojas.filter(l => l.ativo).length;
  const valoresMensais: Record<Loja['plano'], number> = { trial: 0, starter: 99, professional: 199, premium: 399 };
  const mrr = lojas.filter(l => l.ativo).reduce((s, l) => s + valoresMensais[l.plano], 0);

  return (
    <div className="min-h-screen bg-[#f5f6fa] p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6 sm:mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-serif text-charcoal tracking-tight">Painel Master</h1>
            <p className="text-gray-500 text-sm mt-1">Gerencie todas as lojas e seus administradores</p>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/super-admin/admins"
              className="inline-flex items-center justify-center gap-2 bg-white border border-gray-200 text-charcoal px-4 py-2.5 rounded-xl text-sm font-semibold hover:bg-gray-50 transition-all">
              <Shield size={16} /> Admins
            </Link>
            <button onClick={() => setModalNova(true)}
              className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-purple-700 text-white px-5 py-2.5 rounded-xl text-sm font-semibold shadow-md shadow-purple-500/20 hover:from-purple-700 hover:to-purple-800 transition-all">
              <Plus size={16} /> Nova Loja
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6">
          {[
            { titulo: 'Lojas Ativas', valor: `${lojasAtivas}/${totalLojas}`, icon: Store, cor: 'bg-purple-100 text-purple-600' },
            { titulo: 'MRR Estimado', valor: `R$ ${mrr.toLocaleString('pt-BR')}`, icon: ShoppingCart, cor: 'bg-emerald-100 text-emerald-600' },
            { titulo: 'Total Produtos', valor: lojas.reduce((s, l) => s + (l._stats?.produtos ?? 0), 0), icon: Package, cor: 'bg-amber-100 text-amber-600' },
            { titulo: 'Total Pedidos', valor: lojas.reduce((s, l) => s + (l._stats?.pedidos ?? 0), 0), icon: Users, cor: 'bg-blue-100 text-blue-600' },
          ].map(s => (
            <div key={s.titulo} className="bg-white border border-gray-100 rounded-2xl p-4 sm:p-5">
              <div className={`w-9 h-9 sm:w-11 sm:h-11 rounded-xl ${s.cor} flex items-center justify-center mb-3`}>
                <s.icon size={18} />
              </div>
              <p className="text-xl sm:text-2xl font-bold text-charcoal">{s.valor}</p>
              <p className="text-[10px] sm:text-xs text-gray-400 mt-1 font-medium">{s.titulo}</p>
            </div>
          ))}
        </div>

        {/* Lojas */}
        {loading ? (
          <div className="bg-white rounded-2xl py-16 text-center border border-gray-100">
            <div className="w-6 h-6 border-2 border-purple-300 border-t-purple-600 rounded-full animate-spin mx-auto mb-3" />
            <p className="text-gray-400 text-sm">Carregando...</p>
          </div>
        ) : lojas.length === 0 ? (
          <div className="bg-white rounded-2xl py-16 text-center border border-gray-100">
            <Store size={36} className="text-gray-200 mx-auto mb-3" />
            <p className="text-gray-400 mb-4">Nenhuma loja ainda</p>
            <button onClick={() => setModalNova(true)} className="inline-flex items-center gap-2 text-purple-600 text-sm font-semibold">
              <Plus size={14} /> Criar primeira loja
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {lojas.map(loja => {
              const planoInfo = PLANO_INFO[loja.plano];
              return (
                <div key={loja.id} className={`bg-white border rounded-2xl p-5 transition-all ${loja.ativo ? 'border-gray-100 hover:shadow-md' : 'border-red-100 opacity-70'}`}>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="min-w-0 flex-1">
                      <h3 className="font-semibold text-charcoal text-base truncate">{loja.nome}</h3>
                      <p className="text-xs text-gray-400 font-mono">/{loja.slug}</p>
                    </div>
                    <span className={`text-[10px] font-semibold px-2 py-1 rounded-md border flex-shrink-0 ${planoInfo.cor}`}>{planoInfo.label}</span>
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-3 gap-2 mb-4">
                    {[
                      { label: 'Produtos', val: loja._stats?.produtos ?? 0 },
                      { label: 'Pedidos', val: loja._stats?.pedidos ?? 0 },
                      { label: 'Clientes', val: loja._stats?.clientes ?? 0 },
                    ].map(s => (
                      <div key={s.label} className="bg-gray-50 rounded-xl p-2 text-center">
                        <p className="text-base font-bold text-charcoal">{s.val}</p>
                        <p className="text-[9px] text-gray-400 uppercase tracking-wider font-semibold">{s.label}</p>
                      </div>
                    ))}
                  </div>

                  <p className="text-xs text-gray-500 mb-4 truncate">📧 {loja.email_admin}</p>

                  {/* Ações */}
                  <div className="grid grid-cols-4 gap-1 pt-3 border-t border-gray-100">
                    <button onClick={() => abrirAdmins(loja)}
                      title="Gerenciar admins desta loja"
                      className="flex flex-col items-center gap-1 text-purple-600 hover:bg-purple-50 py-2 rounded-xl transition-colors text-[11px] font-semibold">
                      <UserPlus size={14} /> Admins
                    </button>
                    <button onClick={() => setModalDetalhes(loja)}
                      title="Ver detalhes e ações da loja"
                      className="flex flex-col items-center gap-1 text-gray-500 hover:bg-gray-50 py-2 rounded-xl transition-colors text-[11px] font-semibold">
                      <ExternalLink size={14} /> Ver
                    </button>
                    <button onClick={() => toggleAtivo(loja)}
                      title={loja.ativo ? 'Desativar loja (não exclui)' : 'Reativar loja'}
                      className={`flex flex-col items-center gap-1 py-2 rounded-xl transition-colors text-[11px] font-semibold ${loja.ativo ? 'text-amber-600 hover:bg-amber-50' : 'text-emerald-600 hover:bg-emerald-50'}`}>
                      <Power size={14} /> {loja.ativo ? 'Desat.' : 'Ativar'}
                    </button>
                    {loja.id !== '00000000-0000-0000-0000-000000000001' ? (
                      <button onClick={() => deletarLoja(loja)}
                        title="EXCLUIR loja permanentemente"
                        className="flex flex-col items-center gap-1 text-red-600 hover:bg-red-50 py-2 rounded-xl transition-colors text-[11px] font-semibold">
                        <Trash2 size={14} /> Excluir
                      </button>
                    ) : (
                      <div className="flex flex-col items-center gap-1 text-gray-300 py-2 text-[11px] font-semibold" title="Loja principal — não pode ser excluída">
                        <Trash2 size={14} /> —
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ─── MODAL DETALHES DA LOJA ─── */}
      {modalDetalhes && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setModalDetalhes(null)}>
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            {/* Header */}
            <div className="bg-gradient-to-r from-purple-600 to-indigo-700 text-white p-6 rounded-t-2xl">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                    <Store size={26} />
                  </div>
                  <div>
                    <h3 className="font-serif text-2xl">{modalDetalhes.nome}</h3>
                    <p className="text-purple-100/80 text-sm">/{modalDetalhes.slug}</p>
                  </div>
                </div>
                <button onClick={() => setModalDetalhes(null)} className="text-white/70 hover:text-white p-1">
                  <X size={20} />
                </button>
              </div>
              <div className="flex flex-wrap items-center gap-2 mt-4">
                <span className={`text-[11px] px-2.5 py-1 rounded-md font-bold uppercase tracking-wider ${PLANO_INFO[modalDetalhes.plano].cor}`}>
                  {PLANO_INFO[modalDetalhes.plano].label}
                </span>
                <span className={`text-[11px] px-2.5 py-1 rounded-md font-bold uppercase tracking-wider ${modalDetalhes.ativo ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                  {modalDetalhes.ativo ? '✓ Ativa' : '✕ Inativa'}
                </span>
              </div>
            </div>

            {/* Conteúdo */}
            <div className="p-6 space-y-5">
              {/* Stats */}
              {modalDetalhes._stats && (
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-4 text-center">
                    <Package size={18} className="text-blue-600 mx-auto mb-1" />
                    <p className="text-2xl font-bold text-blue-900">{modalDetalhes._stats.produtos}</p>
                    <p className="text-[10px] uppercase tracking-wider text-blue-700 font-semibold">Produtos</p>
                  </div>
                  <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-4 text-center">
                    <ShoppingCart size={18} className="text-purple-600 mx-auto mb-1" />
                    <p className="text-2xl font-bold text-purple-900">{modalDetalhes._stats.pedidos}</p>
                    <p className="text-[10px] uppercase tracking-wider text-purple-700 font-semibold">Pedidos</p>
                  </div>
                  <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-xl p-4 text-center">
                    <Users size={18} className="text-emerald-600 mx-auto mb-1" />
                    <p className="text-2xl font-bold text-emerald-900">{modalDetalhes._stats.clientes}</p>
                    <p className="text-[10px] uppercase tracking-wider text-emerald-700 font-semibold">Clientes</p>
                  </div>
                </div>
              )}

              {/* Contato */}
              <div>
                <p className="text-[10px] uppercase tracking-wider font-bold text-gray-400 mb-2">Contato</p>
                <div className="space-y-1.5 bg-gray-50 rounded-xl p-4">
                  <div className="flex items-center gap-2 text-sm text-charcoal">
                    <Mail size={14} className="text-gray-400 flex-shrink-0" />
                    <span className="break-all">{modalDetalhes.email_admin}</span>
                  </div>
                  {modalDetalhes.telefone_admin && (
                    <div className="flex items-center gap-2 text-sm text-charcoal">
                      <Phone size={14} className="text-gray-400 flex-shrink-0" />
                      <span>{modalDetalhes.telefone_admin}</span>
                    </div>
                  )}
                  {modalDetalhes.dominio && (
                    <div className="flex items-center gap-2 text-sm text-charcoal">
                      <Globe size={14} className="text-gray-400 flex-shrink-0" />
                      <a href={`https://${modalDetalhes.dominio}`} target="_blank" rel="noopener" className="text-purple-600 hover:underline break-all">
                        {modalDetalhes.dominio}
                      </a>
                    </div>
                  )}
                </div>
              </div>

              {/* Domínio Personalizado */}
              <BlocoDominio loja={modalDetalhes} onSalvar={salvarDominio} salvando={salvando} />

              {/* Plano e Limites */}
              <div>
                <p className="text-[10px] uppercase tracking-wider font-bold text-gray-400 mb-2">Plano e Limites</p>
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-gray-50 rounded-xl p-3">
                    <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-1">
                      <CreditCard size={12} /> Plano
                    </div>
                    <p className="font-semibold text-charcoal capitalize">{modalDetalhes.plano}</p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-3">
                    <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-1">
                      <Hash size={12} /> Limite Produtos
                    </div>
                    <p className="font-semibold text-charcoal">{modalDetalhes.limite_produtos.toLocaleString('pt-BR')}</p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-3">
                    <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-1">
                      <ShoppingCart size={12} /> Limite Pedidos
                    </div>
                    <p className="font-semibold text-charcoal">{modalDetalhes.limite_pedidos.toLocaleString('pt-BR')}</p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-3">
                    <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-1">
                      <Calendar size={12} /> Criada em
                    </div>
                    <p className="font-semibold text-charcoal text-sm">
                      {new Date(modalDetalhes.created_at).toLocaleDateString('pt-BR')}
                    </p>
                  </div>
                </div>
              </div>

              {/* Datas importantes */}
              {(modalDetalhes.trial_ate || modalDetalhes.expira_em) && (
                <div>
                  <p className="text-[10px] uppercase tracking-wider font-bold text-gray-400 mb-2">Validade</p>
                  <div className="grid grid-cols-2 gap-3">
                    {modalDetalhes.trial_ate && (
                      <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
                        <p className="text-[10px] uppercase tracking-wider text-amber-700 font-bold mb-1">🧪 Trial até</p>
                        <p className="font-semibold text-amber-900 text-sm">
                          {new Date(modalDetalhes.trial_ate).toLocaleDateString('pt-BR')}
                        </p>
                      </div>
                    )}
                    {modalDetalhes.expira_em && (
                      <div className="bg-rose-50 border border-rose-200 rounded-xl p-3">
                        <p className="text-[10px] uppercase tracking-wider text-rose-700 font-bold mb-1">⏰ Expira em</p>
                        <p className="font-semibold text-rose-900 text-sm">
                          {new Date(modalDetalhes.expira_em).toLocaleDateString('pt-BR')}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* ID técnico */}
              <div className="border-t border-gray-100 pt-4">
                <p className="text-[10px] uppercase tracking-wider font-bold text-gray-400 mb-1">ID da Loja</p>
                <code className="text-xs text-gray-600 bg-gray-50 px-2 py-1 rounded font-mono break-all">
                  {modalDetalhes.id}
                </code>
              </div>

              {/* Ações */}
              <div className="flex flex-wrap gap-2 pt-4 border-t border-gray-100">
                <button onClick={() => { abrirAdmins(modalDetalhes); setModalDetalhes(null); }}
                  className="flex-1 min-w-[140px] flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-700 text-white py-2.5 px-4 rounded-xl text-sm font-semibold transition-all">
                  <UserPlus size={15} /> Gerenciar Admins
                </button>
                <button onClick={() => aplicarTemplate(modalDetalhes)} disabled={aplicandoTemplate}
                  className="flex-1 min-w-[140px] flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white py-2.5 px-4 rounded-xl text-sm font-semibold transition-all disabled:opacity-50">
                  📦 {aplicandoTemplate ? 'Aplicando...' : 'Aplicar Template'}
                </button>
                <button onClick={() => limparTemplate(modalDetalhes)} disabled={aplicandoTemplate}
                  className="flex-1 min-w-[140px] flex items-center justify-center gap-2 bg-white hover:bg-red-50 border border-red-200 text-red-600 py-2.5 px-4 rounded-xl text-sm font-semibold transition-all disabled:opacity-50"
                  title="Remove apenas produtos [EXEMPLO] e [DEMO] desta loja">
                  🧹 Limpar Template
                </button>
                <button onClick={() => zerarLoja(modalDetalhes)} disabled={aplicandoTemplate}
                  className="flex-1 min-w-[140px] flex items-center justify-center gap-2 bg-yellow-50 hover:bg-yellow-100 border border-yellow-400 text-yellow-800 py-2.5 px-4 rounded-xl text-sm font-semibold transition-all disabled:opacity-50"
                  title="Remove TUDO (produtos, categorias, configs). Preserva pedidos e admins.">
                  ♻️ Zerar Loja
                </button>
                {modalDetalhes.id !== '00000000-0000-0000-0000-000000000001' && (
                  <button onClick={() => deletarLoja(modalDetalhes)} disabled={aplicandoTemplate}
                    className="flex-1 min-w-[140px] flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white py-2.5 px-4 rounded-xl text-sm font-semibold transition-all disabled:opacity-50"
                    title="EXCLUI a loja permanentemente (irreversível)">
                    🗑️ Excluir Loja
                  </button>
                )}
                {modalDetalhes.dominio && (
                  <a href={`https://${modalDetalhes.dominio}`} target="_blank" rel="noopener"
                    className="flex-1 min-w-[140px] flex items-center justify-center gap-2 bg-white border border-gray-200 hover:bg-gray-50 text-charcoal py-2.5 px-4 rounded-xl text-sm font-semibold transition-all">
                    <ExternalLink size={15} /> Abrir Site
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ─── MODAL ADMINS DA LOJA ─── */}
      {modalAdmin && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setModalAdmin(null)}>
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            {/* Header */}
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <div>
                <h3 className="font-serif text-lg text-charcoal">Admins — {modalAdmin.nome}</h3>
                <p className="text-xs text-gray-400 mt-0.5">Gerencie quem acessa o /admin desta loja</p>
              </div>
              <button onClick={() => setModalAdmin(null)} className="text-gray-400 hover:text-charcoal p-1">
                <X size={20} />
              </button>
            </div>

            <div className="p-5 space-y-5">
              {/* Lista de admins existentes */}
              <div>
                <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-3">Administradores atuais</p>
                {loadingAdmins ? (
                  <div className="py-6 text-center">
                    <div className="w-5 h-5 border-2 border-purple-300 border-t-purple-600 rounded-full animate-spin mx-auto" />
                  </div>
                ) : adminsLoja.length === 0 ? (
                  <div className="bg-gray-50 rounded-xl p-4 text-center">
                    <Users size={24} className="text-gray-200 mx-auto mb-2" />
                    <p className="text-xs text-gray-400">Nenhum admin cadastrado ainda</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {adminsLoja.map(admin => (
                      <CardAdmin
                        key={admin.id}
                        admin={admin}
                        lojaId={modalAdmin?.id || ''}
                        onAtualizado={(novoAdmin) => setAdminsLoja(prev => prev.map(a => a.id === novoAdmin.id ? { ...a, ...novoAdmin } : a))}
                        onRemovido={() => setAdminsLoja(prev => prev.filter(a => a.id !== admin.id))}
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* Adicionar novo admin */}
              <div className="border border-purple-200 bg-purple-50/40 rounded-xl p-4 space-y-3">
                <p className="text-[10px] font-semibold text-purple-600 uppercase tracking-wider">Adicionar administrador</p>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider block mb-1">Nome *</label>
                    <input value={novoAdmin.nome} onChange={e => setNovoAdmin(p => ({ ...p, nome: e.target.value }))}
                      placeholder="Nome completo"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-purple-500 bg-white" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider block mb-1">Email *</label>
                    <input type="email" value={novoAdmin.email} onChange={e => setNovoAdmin(p => ({ ...p, email: e.target.value }))}
                      placeholder="email@loja.com"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-purple-500 bg-white" />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider block mb-1">Senha de acesso *</label>
                  <div className="relative">
                    <input
                      type={mostrarSenha ? 'text' : 'password'}
                      value={novoAdmin.senha}
                      onChange={e => setNovoAdmin(p => ({ ...p, senha: e.target.value }))}
                      placeholder="Mínimo 6 caracteres"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-purple-500 bg-white pr-10"
                    />
                    <button type="button" onClick={() => setMostrarSenha(!mostrarSenha)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                      {mostrarSenha ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                  <p className="text-[10px] text-gray-400 mt-1">
                    ⚠️ Anote a senha — ela não pode ser recuperada depois. Se o usuário já tem conta, pode deixar em branco (será apenas vinculado).
                  </p>
                </div>

                <button onClick={criarAdmin} disabled={salvando}
                  className="w-full bg-gradient-to-r from-purple-600 to-purple-700 text-white py-2.5 rounded-xl text-sm font-semibold disabled:opacity-50 hover:from-purple-700 hover:to-purple-800 transition-all flex items-center justify-center gap-2">
                  {salvando ? <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Criando...</> : <><UserPlus size={14} /> Criar Admin</>}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ─── MODAL NOVA LOJA ─── */}
      {modalNova && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setModalNova(false)}>
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="font-serif text-xl text-charcoal">Nova Loja</h3>
                <p className="text-xs text-gray-400 mt-0.5">Cadastre um novo cliente</p>
              </div>
              <button onClick={() => setModalNova(false)} className="text-gray-400 hover:text-charcoal p-1"><X size={20} /></button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1">Nome da Loja *</label>
                <input value={novaLoja.nome} onChange={e => setNovaLoja(p => ({ ...p, nome: e.target.value, slug: gerarSlug(e.target.value) }))}
                  placeholder="Ex: Maria Boutique"
                  className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-purple-500" />
              </div>
              <div>
                <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1">Slug (URL) *</label>
                <div className="flex items-center gap-1 bg-gray-50 rounded-xl border border-gray-200 px-3 py-2.5">
                  <input value={novaLoja.slug} onChange={e => setNovaLoja(p => ({ ...p, slug: gerarSlug(e.target.value) }))}
                    placeholder="mariaboutique" className="flex-1 bg-transparent text-sm outline-none font-mono" />
                  <span className="text-xs text-gray-400">.sua-marca.com</span>
                </div>
              </div>
              <div>
                <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1">Email de contato *</label>
                <input type="email" value={novaLoja.email_admin} onChange={e => setNovaLoja(p => ({ ...p, email_admin: e.target.value }))}
                  placeholder="cliente@email.com"
                  className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-purple-500" />
              </div>
              <div>
                <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1">Telefone</label>
                <input value={novaLoja.telefone_admin} onChange={e => setNovaLoja(p => ({ ...p, telefone_admin: e.target.value }))}
                  placeholder="(81) 99999-9999"
                  className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-purple-500" />
              </div>
              <div>
                <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1">Plano</label>
                <select value={novaLoja.plano} onChange={e => setNovaLoja(p => ({ ...p, plano: e.target.value as Loja['plano'] }))}
                  className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-purple-500">
                  <option value="trial">🧪 Trial 7 dias (grátis)</option>
                  <option value="starter">🟢 Starter — R$ 99/mês</option>
                  <option value="professional">🔵 Professional — R$ 199/mês</option>
                  <option value="premium">🟣 Premium — R$ 399/mês</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1">Domínio próprio (opcional)</label>
                <input value={novaLoja.dominio} onChange={e => setNovaLoja(p => ({ ...p, dominio: e.target.value }))}
                  placeholder="lojadocliente.com.br"
                  className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-purple-500" />
              </div>

              {/* Admin da loja */}
              <div className="border-t border-gray-200 pt-3 mt-3">
                <div className="flex items-center gap-2 mb-2">
                  <UserPlus size={14} className="text-purple-600" />
                  <span className="text-xs font-bold text-charcoal uppercase tracking-wider">Admin desta loja</span>
                </div>
                <p className="text-[10px] text-gray-500 mb-3">
                  Este é o login que o cliente vai usar para acessar o painel da loja dele.
                </p>

                <div className="space-y-2">
                  <div>
                    <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1">Nome do admin *</label>
                    <input value={novaLojaAdmin.nome} onChange={e => setNovaLojaAdmin(p => ({ ...p, nome: e.target.value }))}
                      placeholder="Ex: Maria Silva"
                      className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-purple-500" />
                  </div>
                  <div>
                    <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1">E-mail do admin *</label>
                    <input type="email" value={novaLojaAdmin.email} onChange={e => setNovaLojaAdmin(p => ({ ...p, email: e.target.value }))}
                      placeholder="maria@boutique.com"
                      className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-purple-500" />
                  </div>
                  <div>
                    <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block mb-1">Senha temporária *</label>
                    <div className="relative">
                      <input type={mostrarSenha ? 'text' : 'password'} value={novaLojaAdmin.senha}
                        onChange={e => setNovaLojaAdmin(p => ({ ...p, senha: e.target.value }))}
                        placeholder="Mínimo 6 caracteres"
                        className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-purple-500 pr-10" />
                      <button type="button" onClick={() => setMostrarSenha(!mostrarSenha)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-charcoal">
                        {mostrarSenha ? <EyeOff size={14} /> : <Eye size={14} />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Template */}
              <div className="border-t border-gray-200 pt-3 mt-3">
                <label className="flex items-start gap-2 cursor-pointer">
                  <input type="checkbox" checked={incluirTemplate} onChange={e => setIncluirTemplate(e.target.checked)}
                    className="mt-1 w-4 h-4 rounded text-purple-600 focus:ring-purple-500" />
                  <div className="flex-1">
                    <span className="text-xs font-bold text-charcoal block">📦 Incluir dados de exemplo</span>
                    <span className="text-[10px] text-gray-500 block mt-0.5">
                      Cria 3 categorias e 3 produtos fictícios marcados como [EXEMPLO]. O admin pode editar ou excluir tudo depois.
                    </span>
                  </div>
                </label>
              </div>

              {/* URL Provisória + Checklist */}
              {novaLoja.slug && !novaLoja.dominio && (
                <PainelChecklistSubdominio slug={novaLoja.slug} nomeLoja={novaLoja.nome} emailAdmin={novaLojaAdmin.email} />
              )}
            </div>

            <div className="flex gap-2 mt-5">
              <button onClick={criarLoja} disabled={salvando}
                className="flex-1 bg-gradient-to-r from-purple-600 to-purple-700 text-white py-3 rounded-xl text-sm font-semibold disabled:opacity-50 hover:from-purple-700 hover:to-purple-800 transition-all">
                {salvando ? 'Criando...' : 'Criar Loja Completa'}
              </button>
              <button onClick={() => setModalNova(false)} className="px-4 text-sm text-gray-500 hover:text-charcoal">Cancelar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function BlocoDominio({ loja, onSalvar, salvando }: { loja: Loja; onSalvar: (l: Loja, d: string) => Promise<boolean>; salvando: boolean }) {
  const [editando, setEditando] = useState(false);
  const [valor, setValor] = useState(loja.dominio || '');
  const [mostraGuia, setMostraGuia] = useState(false);

  async function handleSalvar() {
    const ok = await onSalvar(loja, valor.trim());
    if (ok) setEditando(false);
  }

  return (
    <div className="bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-100 rounded-xl p-4">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Globe size={14} className="text-indigo-600" />
          <p className="text-xs font-bold text-charcoal uppercase tracking-wider">Domínio Personalizado</p>
        </div>
        {!editando && (
          <button onClick={() => setEditando(true)} className="text-[11px] text-indigo-600 hover:underline font-semibold">
            {loja.dominio ? 'Editar' : '+ Adicionar'}
          </button>
        )}
      </div>

      {!editando && loja.dominio && (
        <div className="bg-white rounded-lg p-2 flex items-center gap-2">
          <span className="text-emerald-500">●</span>
          <a href={`https://${loja.dominio}`} target="_blank" rel="noopener" className="text-sm font-mono text-charcoal hover:text-indigo-600 break-all">
            {loja.dominio}
          </a>
        </div>
      )}

      {!editando && !loja.dominio && (
        <p className="text-xs text-gray-500 italic">Nenhum domínio configurado. A loja só acessa pela URL padrão.</p>
      )}

      {editando && (
        <div className="space-y-2">
          <input
            type="text"
            value={valor}
            onChange={e => setValor(e.target.value)}
            placeholder="ex: mariaboutique.com.br"
            className="w-full bg-white border border-indigo-200 rounded-lg px-3 py-2 text-sm font-mono outline-none focus:border-indigo-500"
          />
          <p className="text-[10px] text-gray-500">
            Sem http:// ou www. Apenas o domínio (ex: <code className="bg-white px-1 rounded">lojadocliente.com.br</code>)
          </p>
          <div className="flex gap-2">
            <button onClick={handleSalvar} disabled={salvando}
              className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold px-3 py-2 rounded-lg disabled:opacity-50">
              {salvando ? 'Salvando...' : 'Salvar'}
            </button>
            <button onClick={() => { setEditando(false); setValor(loja.dominio || ''); }}
              className="px-3 py-2 text-xs text-gray-500 hover:text-charcoal">
              Cancelar
            </button>
          </div>
        </div>
      )}

      {/* Instruções DNS */}
      <button onClick={() => setMostraGuia(!mostraGuia)} className="mt-3 text-[11px] text-indigo-600 hover:underline font-semibold flex items-center gap-1">
        {mostraGuia ? '▾' : '▸'} Como configurar DNS no domínio do cliente
      </button>

      {mostraGuia && (
        <div className="mt-2 bg-white rounded-lg p-3 text-[11px] text-charcoal space-y-2">
          <p className="font-bold">📋 Instrua o cliente a criar estes registros no DNS dele:</p>
          <div className="bg-gray-50 rounded p-2 font-mono space-y-0.5">
            <div><span className="text-gray-500">Tipo:</span> A · <span className="text-gray-500">Nome:</span> @ · <span className="text-gray-500">Valor:</span> {process.env.NEXT_PUBLIC_VPS_IP || '<IP_DO_SEU_VPS>'}</div>
            <div><span className="text-gray-500">Tipo:</span> A · <span className="text-gray-500">Nome:</span> www · <span className="text-gray-500">Valor:</span> {process.env.NEXT_PUBLIC_VPS_IP || '<IP_DO_SEU_VPS>'}</div>
          </div>
          <p className="font-bold">⚙️ Depois, no EasyPanel:</p>
          <ol className="list-decimal list-inside space-y-1 text-gray-700">
            <li>App → Domains → Add Domain</li>
            <li>Cole: <code className="bg-gray-100 px-1 rounded">{valor || loja.dominio || 'dominio.com.br'}</code></li>
            <li>Marque "Generate SSL certificate" (HTTPS automático)</li>
            <li>Aguarde propagação DNS (5min a 24h)</li>
          </ol>
        </div>
      )}
    </div>
  );
}

function PainelChecklistSubdominio({ slug, nomeLoja, emailAdmin }: { slug: string; nomeLoja: string; emailAdmin: string }) {
  const [copiou, setCopiou] = useState(false);
  const [vpsIp] = useState(process.env.NEXT_PUBLIC_VPS_IP || '');
  const dominioBase = 'bymarcelomedeiros.com.br';
  const urlProvisoria = `${slug}.${dominioBase}`;

  const checklist = `🎯 NOVA LOJA: ${nomeLoja}
📧 Admin: ${emailAdmin}
🌐 URL provisória: https://${urlProvisoria}

═══════════════════════════════════════
✅ CHECKLIST DE ATIVAÇÃO (3 passos)
═══════════════════════════════════════

▸ PASSO 1 — Cloudflare DNS
  Add A record:
  • Type: A
  • Name: ${slug}
  • Content: ${vpsIp || '<IP do VPS>'}
  • Proxy status: DNS only (cinza)
  • TTL: Auto

▸ PASSO 2 — EasyPanel
  App → Domains → Add Domain:
  • Host: ${urlProvisoria}
  • Path: /
  • Protocol: HTTP
  • Port: 3000
  • SSL → Certificate Resolver: letsencrypt
  • SSL → Wildcard: OFF
  • Click Create (SSL automático em ~1min)

▸ PASSO 3 — Testa
  Acessa: https://${urlProvisoria}
  → Deve carregar a loja "${nomeLoja}"

═══════════════════════════════════════
🔄 Quando o cliente comprar domínio próprio:
   Painel Master → Ver loja → Editar Domínio
═══════════════════════════════════════`;

  async function copiar() {
    try {
      await navigator.clipboard.writeText(checklist);
      setCopiou(true);
      toast.success('Checklist copiado!');
      setTimeout(() => setCopiou(false), 2500);
    } catch {
      toast.error('Erro ao copiar');
    }
  }

  return (
    <div className="border-t border-gray-200 pt-3 mt-3">
      <div className="bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-200 rounded-xl p-4">
        <div className="flex items-center gap-2 mb-3">
          <Globe size={14} className="text-indigo-600" />
          <p className="text-xs font-bold text-charcoal uppercase tracking-wider">URL Provisória</p>
        </div>

        <div className="bg-white rounded-lg p-3 mb-3 border border-indigo-100">
          <p className="text-[10px] text-gray-500 mb-1">A loja vai ficar acessível em:</p>
          <p className="text-sm font-mono font-bold text-indigo-700 break-all">
            https://{urlProvisoria}
          </p>
        </div>

        <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-3">
          <p className="text-[11px] font-bold text-amber-800 mb-1.5">⚠️ Você precisa fazer 2 passos manuais depois de criar:</p>
          <ol className="text-[11px] text-amber-900 space-y-1 list-decimal list-inside">
            <li><strong>Cloudflare:</strong> Add A record · Name: <code className="bg-white px-1 rounded">{slug}</code> · IP do VPS · DNS only (cinza)</li>
            <li><strong>EasyPanel:</strong> Add Domain · <code className="bg-white px-1 rounded">{urlProvisoria}</code> · SSL letsencrypt</li>
          </ol>
        </div>

        <button
          type="button"
          onClick={copiar}
          className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-semibold transition-all ${
            copiou
              ? 'bg-emerald-500 text-white'
              : 'bg-indigo-600 hover:bg-indigo-700 text-white'
          }`}
        >
          {copiou ? '✓ Copiado!' : '📋 Copiar checklist completo (3 passos)'}
        </button>

        <p className="text-[10px] text-gray-500 mt-2 text-center">
          Cole o checklist em qualquer lugar pra não esquecer dos passos
        </p>
      </div>
    </div>
  );
}

function CardAdmin({ admin, lojaId, onAtualizado, onRemovido }: {
  admin: AdminLoja;
  lojaId: string;
  onAtualizado: (a: AdminLoja) => void;
  onRemovido: () => void;
}) {
  const [editando, setEditando] = useState(false);
  const [nome, setNome] = useState(admin.nome);
  const [email, setEmail] = useState(admin.email);
  const [senha, setSenha] = useState('');
  const [salvando, setSalvando] = useState(false);
  const [mostrarSenha, setMostrarSenha] = useState(false);

  async function salvar() {
    const updates: Record<string, string> = {};
    if (nome !== admin.nome) updates.nome = nome;
    if (email !== admin.email) updates.email = email;
    if (senha) updates.senha = senha;

    if (Object.keys(updates).length === 0) {
      setEditando(false);
      return;
    }

    setSalvando(true);
    try {
      const res = await fetch('/api/super-admin/criar-admin', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ admin_id: admin.id, loja_id: lojaId, ...updates }),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error || 'Erro'); return; }
      toast.success(data.mensagem || 'Admin atualizado');
      onAtualizado({ ...admin, nome, email });
      setSenha('');
      setEditando(false);
    } catch { toast.error('Erro de conexão'); }
    finally { setSalvando(false); }
  }

  async function remover() {
    if (!confirm(`Remover o admin "${admin.nome}" (${admin.email})?\n\nO usuário não vai mais conseguir acessar essa loja.`)) return;
    try {
      const res = await fetch('/api/super-admin/criar-admin', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ admin_id: admin.id, loja_id: lojaId }),
      });
      if (!res.ok) { const d = await res.json(); toast.error(d.error || 'Erro'); return; }
      toast.success('Admin removido');
      onRemovido();
    } catch { toast.error('Erro de conexão'); }
  }

  if (editando) {
    return (
      <div className="bg-purple-50 border border-purple-200 rounded-xl p-3 space-y-2">
        <input value={nome} onChange={e => setNome(e.target.value)} placeholder="Nome"
          className="w-full bg-white border border-purple-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-purple-500" />
        <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email"
          className="w-full bg-white border border-purple-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-purple-500" />
        <div className="relative">
          <input type={mostrarSenha ? 'text' : 'password'} value={senha}
            onChange={e => setSenha(e.target.value)}
            placeholder="Nova senha (deixe vazio pra manter)"
            className="w-full bg-white border border-purple-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-purple-500 pr-10" />
          <button type="button" onClick={() => setMostrarSenha(!mostrarSenha)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-charcoal">
            {mostrarSenha ? <EyeOff size={14} /> : <Eye size={14} />}
          </button>
        </div>
        <div className="flex gap-2 pt-1">
          <button onClick={salvar} disabled={salvando}
            className="flex-1 bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold py-2 rounded-lg disabled:opacity-50">
            {salvando ? 'Salvando...' : 'Salvar'}
          </button>
          <button onClick={() => { setEditando(false); setNome(admin.nome); setEmail(admin.email); setSenha(''); }}
            className="px-3 py-2 text-xs text-gray-500 hover:text-charcoal">
            Cancelar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-3 bg-gray-50 rounded-xl p-3 group">
      <div className="w-9 h-9 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 font-bold text-sm flex-shrink-0">
        {admin.nome[0]?.toUpperCase()}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-charcoal truncate">{admin.nome}</p>
        <p className="text-xs text-gray-400 truncate">{admin.email}</p>
      </div>
      <div className="flex items-center gap-1 flex-shrink-0">
        <button onClick={() => setEditando(true)} title="Editar"
          className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-all">
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
        </button>
        <button onClick={remover} title="Remover"
          className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all">
          <Trash2 size={14} />
        </button>
      </div>
    </div>
  );
}
