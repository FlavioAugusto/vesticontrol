/**
 * Cliente Melhor Envio — Multi-tenant
 *
 * Recebe token como parâmetro (de configurações da loja).
 * Fallback pra variável de ambiente apenas se a loja não configurou.
 */

const ME_API_PROD = 'https://melhorenvio.com.br/api/v2';
const ME_API_SANDBOX = 'https://sandbox.melhorenvio.com.br/api/v2';

function getApiUrl(): string {
  return process.env.NODE_ENV === 'production'
    ? (process.env.MELHORENVIO_API_URL || ME_API_PROD)
    : (process.env.MELHORENVIO_SANDBOX_URL || ME_API_SANDBOX);
}

export interface FreteOption {
  id: number;
  name: string;
  company: { name: string; picture: string };
  price: string;
  custom_price: string;
  delivery_time: number;
  custom_delivery_range: { min: number; max: number };
  error: string | null;
}

export interface ProdutoFrete {
  id: string;
  weight: number;
  width: number;
  height: number;
  length: number;
  quantity: number;
  insurance_value: number;
}

export interface CalcularFreteParams {
  cep_origem: string;
  cep_destino: string;
  produtos: ProdutoFrete[];
  token?: string;        // 🆕 Token específico da loja (vem do banco)
  userAgent?: string;    // 🆕 User-Agent personalizado (opcional)
}

export async function calcularFrete(params: CalcularFreteParams): Promise<FreteOption[]> {
  // Prioridade: 1) token do parâmetro (da loja) → 2) token global do env (fallback)
  const token = params.token || process.env.MELHORENVIO_TOKEN;
  if (!token) {
    console.warn('[melhorenvio] Token não configurado');
    return [];
  }

  const userAgent = params.userAgent || 'Multi-loja/1.0 (admin@sualoja.com.br)';

  const res = await fetch(`${getApiUrl()}/me/shipment/calculate`, {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      'User-Agent': userAgent,
    },
    body: JSON.stringify({
      from: { postal_code: params.cep_origem.replace(/\D/g, '') },
      to:   { postal_code: params.cep_destino.replace(/\D/g, '') },
      products: params.produtos,
      services: '1,2,3,4,17',
      options: {
        insurance_value: params.produtos.reduce((s, p) => s + p.insurance_value, 0),
        receipt: false,
        own_hand: false,
      },
    }),
  });

  if (!res.ok) {
    console.error('[melhorenvio] Erro HTTP:', res.status, await res.text());
    return [];
  }

  const data = await res.json();
  return Array.isArray(data) ? data.filter((opt: FreteOption) => !opt.error) : [];
}
