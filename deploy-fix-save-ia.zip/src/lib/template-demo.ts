/**
 * TEMPLATE DEMO COMPLETO
 *
 * Quando uma nova loja é criada pelo super_admin com a opção "incluir template",
 * TUDO daqui é copiado para a loja nova: produtos, categorias, banners,
 * depoimentos, modais legais, configurações de tema, hero slides, footer, etc.
 *
 * O admin da loja nova vai substituir cada peça pelos dados reais dele.
 * Nada aqui faz referência a marcas existentes — é um template neutro de demonstração.
 */

// ═════════════════════════════════════════════════════════════════════════
// CATEGORIAS — 3 categorias prontas
// ═════════════════════════════════════════════════════════════════════════
export const TEMPLATE_CATEGORIAS = [
  {
    nome: 'Lançamentos',
    slug: 'lancamentos',
    descricao: 'As novidades mais recentes da nossa coleção',
    imagem_url: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&h=750&fit=crop&q=85',
    ordem: 1,
  },
  {
    nome: 'Mais Vendidos',
    slug: 'mais-vendidos',
    descricao: 'Os queridinhos das nossas clientes',
    imagem_url: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=600&h=750&fit=crop&q=85',
    ordem: 2,
  },
  {
    nome: 'Promoções',
    slug: 'promocoes',
    descricao: 'Ofertas especiais por tempo limitado',
    imagem_url: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=600&h=750&fit=crop&q=85',
    ordem: 3,
  },
];

// ═════════════════════════════════════════════════════════════════════════
// PRODUTOS — 6 produtos completos (alguns em destaque, alguns em promoção)
// ═════════════════════════════════════════════════════════════════════════
export const TEMPLATE_PRODUTOS = [
  {
    nome: '[DEMO] Vestido Elegance Midi',
    slug: 'demo-vestido-elegance-midi',
    descricao: 'Vestido midi elegante para ocasiões especiais. Tecido nobre, modelagem favorecedora e acabamento impecável.\n\n— Este é um produto de demonstração. Edite ou exclua no admin → Produtos.',
    preco: 299.90,
    preco_antigo: 399.90,
    badge: 'sale',
    destaque: true,
    categoria_slug: 'lancamentos',
    imagem: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800&h=1000&fit=crop&q=80',
  },
  {
    nome: '[DEMO] Conjunto Soft Verão',
    slug: 'demo-conjunto-soft-verao',
    descricao: 'Conjunto leve e versátil para o dia a dia. Conforto e elegância em uma única peça.\n\n— Produto de demonstração.',
    preco: 249.90,
    badge: 'new',
    destaque: true,
    categoria_slug: 'lancamentos',
    imagem: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=800&h=1000&fit=crop&q=80',
  },
  {
    nome: '[DEMO] Vestido Longo Charme',
    slug: 'demo-vestido-longo-charme',
    descricao: 'Vestido longo para momentos especiais. Caimento perfeito e detalhes únicos.\n\n— Produto de demonstração.',
    preco: 459.90,
    destaque: true,
    categoria_slug: 'mais-vendidos',
    imagem: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=800&h=1000&fit=crop&q=80',
  },
  {
    nome: '[DEMO] Blusa Lumière',
    slug: 'demo-blusa-lumiere',
    descricao: 'Blusa feminina sofisticada. Combina com calças e saias para diversos estilos.\n\n— Produto de demonstração.',
    preco: 179.90,
    preco_antigo: 229.90,
    badge: 'sale',
    destaque: true,
    categoria_slug: 'promocoes',
    imagem: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=800&h=1000&fit=crop&q=80',
  },
  {
    nome: '[DEMO] Saia Midi Plissada',
    slug: 'demo-saia-midi-plissada',
    descricao: 'Saia plissada moderna, ideal para o dia e noite.\n\n— Produto de demonstração.',
    preco: 199.90,
    badge: 'new',
    destaque: false,
    categoria_slug: 'mais-vendidos',
    imagem: 'https://images.unsplash.com/photo-1583496661160-fb5886a13d4c?w=800&h=1000&fit=crop&q=80',
  },
  {
    nome: '[DEMO] Vestido Festa Premium',
    slug: 'demo-vestido-festa-premium',
    descricao: 'Vestido de festa com brilho sutil, perfeito para eventos especiais.\n\n— Produto de demonstração.',
    preco: 549.90,
    preco_antigo: 699.90,
    badge: 'sale',
    destaque: false,
    categoria_slug: 'promocoes',
    imagem: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=800&h=1000&fit=crop&q=80',
  },
];

// ═════════════════════════════════════════════════════════════════════════
// HERO SLIDES — 3 banners no carrossel principal
// ═════════════════════════════════════════════════════════════════════════
const HERO_SLIDES = [
  {
    id: '1',
    titulo: 'Nova Coleção',
    subtitulo: 'PRIMAVERA / VERÃO',
    descricao: 'Peças exclusivas que celebram a feminilidade com elegância e estilo único.',
    cta: 'VER COLEÇÃO',
    cta_link: '/produtos',
    imagem: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=1400&h=900&fit=crop&q=90',
    ativo: true,
  },
  {
    id: '2',
    titulo: 'Conjuntos Exclusivos',
    subtitulo: 'NOVA CHEGADA',
    descricao: 'Peças únicas criadas com tecidos selecionados para mulheres modernas.',
    cta: 'EXPLORAR',
    cta_link: '/produtos',
    imagem: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=1400&h=900&fit=crop&q=90',
    ativo: true,
  },
  {
    id: '3',
    titulo: 'Vestidos Longos',
    subtitulo: 'OCASIÕES ESPECIAIS',
    descricao: 'Para momentos únicos que merecem looks verdadeiramente inesquecíveis.',
    cta: 'VER VESTIDOS',
    cta_link: '/produtos',
    imagem: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=1400&h=900&fit=crop&q=90',
    ativo: true,
  },
];

// ═════════════════════════════════════════════════════════════════════════
// BANNERS PROMOCIONAIS — cards entre seções
// ═════════════════════════════════════════════════════════════════════════
const BANNERS_PROMOCIONAIS = [
  {
    titulo: 'Conjuntos\nExclusivos',
    subtitulo: 'Nova Chegada',
    descricao: 'Peças exclusivas para diversas ocasiões.',
    cta: 'Ver Conjuntos',
    link: '/produtos',
    imagem: 'https://images.unsplash.com/photo-1496217590455-aa63a8350eea?w=800&h=600&fit=crop&q=90',
  },
  {
    titulo: 'Vestidos\nLongos',
    subtitulo: 'Ocasiões Especiais',
    descricao: 'Para momentos únicos e inesquecíveis.',
    cta: 'Explorar',
    link: '/produtos',
    imagem: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=800&h=600&fit=crop&q=90',
  },
];

// ═════════════════════════════════════════════════════════════════════════
// DEPOIMENTOS — 3 testemunhos
// ═════════════════════════════════════════════════════════════════════════
const DEPOIMENTOS = [
  {
    id: '1',
    nome: 'Cliente Satisfeita 1',
    cidade: 'São Paulo, SP',
    nota: 5,
    texto: 'Atendimento excelente e produtos de qualidade impecável. Recomendo demais!',
    foto: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop&q=80',
    tipo: 'imagem',
  },
  {
    id: '2',
    nome: 'Cliente Satisfeita 2',
    cidade: 'Rio de Janeiro, RJ',
    nota: 5,
    texto: 'Adorei meu vestido! Tecido lindo e modelagem perfeita. Vou comprar mais!',
    foto: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop&q=80',
    tipo: 'imagem',
  },
  {
    id: '3',
    nome: 'Cliente Satisfeita 3',
    cidade: 'Belo Horizonte, MG',
    nota: 5,
    texto: 'Entrega rápida, embalagem caprichada e produtos lindos. Top demais!',
    foto: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop&q=80',
    tipo: 'imagem',
  },
];

// ═════════════════════════════════════════════════════════════════════════
// CONFIGURAÇÕES — todas as configs que uma loja completa precisa
// ═════════════════════════════════════════════════════════════════════════
export const TEMPLATE_CONFIGS = (loja: { nome: string; email_admin: string; telefone_admin?: string | null }) => ({
  // ─── Identidade ─────────────────────────────────────────────────────────
  loja_nome: loja.nome,
  loja_logo_url: '/images/logo-placeholder.svg',
  loja_favicon_url: '/images/favicon-placeholder.svg',

  // ─── Contato ────────────────────────────────────────────────────────────
  loja_email: loja.email_admin,
  loja_telefone: loja.telefone_admin || '(11) 99999-9999',
  loja_whatsapp: (loja.telefone_admin || '').replace(/\D/g, '') || '11999999999',
  loja_instagram: '@sualoja',
  loja_horario_atendimento: 'Seg–Sex: 9h–18h | Sáb: 9h–13h',
  loja_cnpj: '00.000.000/0001-00',

  // ─── TopBar ─────────────────────────────────────────────────────────────
  topbar_texto: 'FRETE GRÁTIS ACIMA DE R$ 299 · 10% OFF NO PIX',
  topbar_ativo: 'true',

  // ─── Frete e Pagamento ──────────────────────────────────────────────────
  loja_cep_origem: '01000-000',
  frete_gratis_minimo: '299.00',
  parcelas_sem_juros: '6',
  mercadopago_ativo: 'false',
  infinitepay_ativo: 'false',
  melhorenvio_ativo: 'false',
  correios_ativo: 'true',

  // ─── SEO ────────────────────────────────────────────────────────────────
  seo_titulo: `${loja.nome} — Moda Feminina Exclusiva`,
  seo_descricao: `${loja.nome}: peças exclusivas, qualidade premium e atendimento personalizado.`,

  // ─── Rodapé ─────────────────────────────────────────────────────────────
  rodape_texto: 'Moda feminina com elegância, qualidade e estilo único.',
  rodape_endereco: 'Cidade — UF',
  rodape_horario: 'Seg–Sex: 9h–18h | Sáb: 9h–13h',
  rodape_rua: 'Endereço completo da loja',
  rodape_cnpj: '00.000.000/0001-00',
  rodape_credito: 'Edite estas informações no admin → Configurações',
  rodape_mapa_titulo: 'Nossa Localização',
  rodape_mapa_endereco: 'Endereço da loja',
  rodape_mapa_url: '',

  // ─── Hero (slides) ──────────────────────────────────────────────────────
  hero_slides: JSON.stringify(HERO_SLIDES),
  hero_titulo_1: HERO_SLIDES[0].titulo,
  hero_subtitulo_1: HERO_SLIDES[0].subtitulo,
  hero_descricao_1: HERO_SLIDES[0].descricao,
  hero_cta_1: HERO_SLIDES[0].cta,
  hero_cta_link_1: HERO_SLIDES[0].cta_link,
  hero_imagem_1: HERO_SLIDES[0].imagem,

  // ─── Banners Promocionais ───────────────────────────────────────────────
  banners_promocionais: JSON.stringify(BANNERS_PROMOCIONAIS),

  // ─── Trust Bar (selos de confiança) ─────────────────────────────────────
  trustbar_items: JSON.stringify([
    { icone: 'Truck', titulo: 'Frete Grátis', desc: 'Acima de R$ 299' },
    { icone: 'ShieldCheck', titulo: 'Compra Segura', desc: 'Ambiente 100% protegido' },
    { icone: 'CreditCard', titulo: '6x Sem Juros', desc: 'No cartão de crédito' },
    { icone: 'QrCode', titulo: '10% Off no Pix', desc: 'Desconto à vista' },
  ]),

  // ─── Depoimentos ────────────────────────────────────────────────────────
  depoimentos: JSON.stringify(DEPOIMENTOS),

  // ─── Seções (visibilidade) ──────────────────────────────────────────────
  secao_hero_ativo: 'true',
  secao_trustbar_ativo: 'true',
  secao_categorias_ativo: 'true',
  secao_destaques_ativo: 'true',
  secao_banners_promo_ativo: 'true',
  secao_quem_somos_ativo: 'true',
  secao_navegue_categorias_ativo: 'true',
  secao_depoimentos_ativo: 'true',
  secao_newsletter_ativo: 'true',
  secao_afiliados_ativo: 'false',
  secao_mapa_ativo: 'false',

  secao_colecoes_titulo: 'Nossas Coleções',
  secao_colecoes_subtitulo: 'EXPLORE',
  secao_destaques_titulo: 'Destaques',
  secao_destaques_subtitulo: 'SELECIONADOS PARA VOCÊ',
  secao_categorias_titulo: 'Navegue por Nossas Coleções',
  secao_categorias_subtitulo: 'EXPLORE',

  // ─── Quem Somos ─────────────────────────────────────────────────────────
  quemsomos_titulo: 'Sobre Nossa Marca',
  quemsomos_subtitulo: 'Quem Somos',
  quemsomos_descricao: 'Conheça nossa história e missão. Edite este texto no admin para contar sobre sua loja.',
  quemsomos_btn: 'Conhecer Mais',
  quemsomos_historia: '[PERSONALIZE ESTE TEXTO]\n\nConte aqui a história da sua loja: como começou, qual sua missão e o que torna sua marca única.\n\nDestaque seus valores, a qualidade dos produtos e o compromisso com as clientes.\n\nEsse texto aparece na página inicial — capricha! 💎',
  quemsomos_imagem: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1600&h=700&fit=crop&q=85',

  // ─── Capas das Coleções (página inicial) ────────────────────────────────
  cat_img_conjuntos: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&h=750&fit=crop&q=85',
  cat_img_midi: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=600&h=750&fit=crop&q=85',
  cat_img_longos: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=600&h=750&fit=crop&q=85',

  // ─── Newsletter ─────────────────────────────────────────────────────────
  newsletter_titulo: 'Fique por dentro',
  newsletter_desc: 'Cadastre-se e ganhe 10% de desconto na primeira compra + novidades exclusivas.',
  newsletter_btn: 'Quero 10% Off',

  // ─── Modais Legais (com placeholders pra editar) ────────────────────────
  modal_privacidade: `POLÍTICA DE PRIVACIDADE\n\n[PERSONALIZE ESTE TEXTO NO ADMIN]\n\nEste é o modelo padrão. Edite no admin → Configurações → Modais.\n\n1. COLETA DE DADOS\nColetamos apenas dados necessários para processar seu pedido: nome, e-mail, telefone, CPF e endereço.\n\n2. USO DOS DADOS\nUsamos seus dados exclusivamente para: processar pedidos, enviar produtos, oferecer atendimento e enviar promoções (com seu consentimento).\n\n3. COMPARTILHAMENTO\nSeus dados só são compartilhados com transportadoras (para entrega) e gateways de pagamento (para processar pagamento).\n\n4. SEUS DIREITOS (LGPD)\nVocê pode solicitar a qualquer momento: acesso, correção, exclusão dos seus dados.\n\n5. CONTATO\nDúvidas: entre em contato pelo nosso e-mail.`,

  modal_termos: `TERMOS DE USO\n\n[PERSONALIZE ESTE TEXTO NO ADMIN]\n\nAo navegar e comprar nesta loja, você concorda com estes termos.\n\n1. PRODUTOS\nAs imagens dos produtos são meramente ilustrativas. Cores podem variar conforme tela.\n\n2. PEDIDOS\nO pedido só é confirmado após a aprovação do pagamento.\n\n3. ENTREGAS\nO prazo de entrega é informado no checkout e começa a contar após a aprovação do pagamento.\n\n4. TROCAS E DEVOLUÇÕES\nVocê tem 7 dias após o recebimento para solicitar troca ou devolução (Código de Defesa do Consumidor).\n\n5. ALTERAÇÕES\nEstes termos podem ser atualizados a qualquer momento.`,

  modal_pagamento: `FORMAS DE PAGAMENTO\n\n[PERSONALIZE NO ADMIN]\n\n💳 CARTÃO DE CRÉDITO\nAceitamos as principais bandeiras (Visa, Master, Elo, Hipercard, American Express).\nParcelamento em até 6x sem juros.\n\n🟢 PIX\nPagamento instantâneo com 10% de desconto.\nO pedido é processado imediatamente após confirmação.\n\n💰 BOLETO BANCÁRIO\nVencimento em 3 dias úteis.\nO pedido é processado após a confirmação do pagamento (1-2 dias úteis).`,

  modal_frete: `FRETE E ENTREGA\n\n[PERSONALIZE NO ADMIN]\n\n🚚 OPÇÕES DE ENVIO\n• Correios PAC: 5-10 dias úteis\n• Correios SEDEX: 1-3 dias úteis\n• Transportadora própria (regiões selecionadas)\n\n💚 FRETE GRÁTIS\nCompras acima de R$ 299 ganham frete grátis (Correios PAC).\n\n📦 PRAZOS\nO prazo começa a contar após a aprovação do pagamento + 1-2 dias úteis para postagem.\n\n📍 RASTREIO\nVocê recebe o código de rastreio por e-mail assim que o produto é despachado.`,

  modal_tamanhos: `GUIA DE TAMANHOS\n\n[PERSONALIZE NO ADMIN — adicione tabela específica das suas peças]\n\nVESTIDOS E BLUSAS\n• P: 36-38\n• M: 38-40\n• G: 42-44\n• GG: 44-46\n\nCALÇAS\n• 36: cintura 64-68cm\n• 38: cintura 68-72cm\n• 40: cintura 72-76cm\n• 42: cintura 76-80cm\n• 44: cintura 80-84cm\n\n💡 DICA: Em caso de dúvida, escolha o tamanho maior. Para troca, é só nos avisar!`,

  modal_trocas: `TROCAS E DEVOLUÇÕES\n\n[PERSONALIZE NO ADMIN]\n\n📅 PRAZO\nVocê tem 7 dias corridos após o recebimento para solicitar troca ou devolução (CDC).\n\n✅ CONDIÇÕES\n• Produto sem uso, com etiqueta e na embalagem original\n• Não pode estar lavado ou modificado\n• Acompanhar nota fiscal\n\n🔄 COMO FAZER\n1. Entre em contato pelo WhatsApp ou e-mail\n2. Receba o código de postagem (frete por nossa conta)\n3. Aguarde nossa conferência (até 3 dias úteis)\n4. Receba o produto novo (troca) ou estorno (devolução)\n\n💰 ESTORNO\nCartão de crédito: até 2 faturas\nPix/Boleto: até 5 dias úteis na sua conta`,
});

// ═════════════════════════════════════════════════════════════════════════
// Exporta tudo pra uso nos endpoints
// ═════════════════════════════════════════════════════════════════════════
export { HERO_SLIDES, BANNERS_PROMOCIONAIS, DEPOIMENTOS };
